import sqlite3
import datetime
import tkinter

global notif_list
notif_list = []
global current_email

def signup_db(email, password):
    global current_email
    current_email = email
    if email == '' or password == '':
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(signup_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Email Address or Password is empty. Try Again.''')
        Label1.after(2000, Label1.destroy)
        signup_db(email.get(), password.get())

    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT email FROM User")
    all_emails = cursor.fetchall()
    all_emails = [all_emails[i][0] for i in range(len(all_emails))]
    joined = datetime.datetime.now()
    if email in all_emails:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(signup_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Email Address is taken. Try Again.''')
        Label1.after(2000, Label1.destroy)
        signup_db(email.get(), password.get())

    cursor.execute(f"INSERT INTO User (email, password, date_joined, last_update) VALUES ('{email}', '{password}', '{joined}', '{joined}')")
    connection.commit()
    connection.close()
    edit_profile_ui()
    # home_ui()

    return

def login_db(email, password):
    global current_email
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT email FROM User")
    users = cursor.fetchall()
    users = [users[i][0] for i in range(len(users))]
    if email == '' or password == '':
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(login_page)
        Label1.place(relx=0.394, rely=0.302, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Email Address or Password is empty. Try Again.''')
        Label1.after(2000, Label1.destroy)
        login_db(email.get(), password.get())

    if email not in users:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(login_page)
        Label1.place(relx=0.37, rely=0.275, height=24, width=400)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='There is no Email Name as "' + email + '". Try Again.')
        Label1.after(2000, Label1.destroy)
        login_db(email.get(), password.get())

    cursor.execute(f"SELECT password FROM User WHERE email = '{email}';")
    real_password = cursor.fetchone()[0]
    connection.commit()
    connection.close()
    if real_password != password:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(login_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Wrong Password. Try Again.''')
        Label1.after(2000, Label1.destroy)
        login_db(email.get(), password.get())

    current_email = email
    # profilePage_ui()
    home_page_ui()
    return

def delete_account_db():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    # if password == None:
    #     cursor.execute(f"SELECT password FROM User WHERE email = '{email}'")
    #     password = cursor.fetchone()[0]
    # cursor.execute(f"UPDATE User SET password = '{password}', phone_number = '{phone_number}', first_name = '{first_name}', last_name = '{last_name}', birthday = '{birthday}', gender = '{gender}', location_country = '{location_country}', location_province = '{location_province}', location_city = '{location_city}', last_update = '{last_update}', image_path = '{image_path}' WHERE email = '{email}';")
    cursor.execute(f"DELETE FROM User WHERE  email = '{current_email}';")
    connection.commit()
    connection.close()

    profile_page.destroy()
    return

def edit_profile_db(email, phone_number, first_name, last_name, gender, birthday, location_country, location_city, language, summery, feature, accomplishment):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    cursor.execute(f"SELECT first_name, last_name FROM User WHERE email = '{current_email}'")
    name = cursor.fetchone()
    first = name[0]
    last = name[1]

    if ((first_name == '' and last_name == '') and (first == None or first == '') and (last == None or last == '')):
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(edit_profile_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''First Name or Last Name is empty.Try Again.''')
        Label1.after(2000, Label1.destroy)
        edit_profile_db(email, phone_number, first_name.get(), last_name.get(), gender, birthday, location_country, location_city)
    else:
        if (first_name != '' and first_name != None):
            first_name = first_name.capitalize()
            cursor.execute(
                f"UPDATE User SET first_name = '{first_name}' WHERE email = '{email}';")
            connection.commit()

        if (last_name != '' and last_name != None):
            last_name = last_name.capitalize()
            cursor.execute(
                f"UPDATE User SET last_name = '{last_name}' WHERE email = '{email}';")
            connection.commit()

        if phone_number != '' and first_name != None:
            cursor.execute(
                f"UPDATE User SET phone_number = '{phone_number}' WHERE email = '{email}';")
            connection.commit()

        if birthday != '' and birthday != None:
            cursor.execute(
                f"UPDATE User SET birthday = '{birthday}' WHERE email = '{email}';")
            connection.commit()

        if gender != '' and gender != None:
            if gender == 'f': gender = 'F'
            if gender == 'm': gender = 'M'
            cursor.execute(
                f"UPDATE User SET gender = '{gender}' WHERE email = '{email}';")
            connection.commit()

        if location_country != '' and location_country != None:
            location_country = location_country.capitalize()
            cursor.execute(
                f"UPDATE User SET location_country = '{location_country}' WHERE email = '{email}';")
            connection.commit()

        if location_city != '' and location_city != None:
            location_city = location_city.capitalize()
            cursor.execute(
                f"UPDATE User SET location_city = '{location_city}' WHERE email = '{email}';")
            connection.commit()

        if language != '' and language != None:
            language = language.capitalize()
            cursor.execute(
                f"UPDATE User SET language = '{language}' WHERE email = '{email}';")
            connection.commit()

        if summery != '' and summery != None:
            cursor.execute(
                f"UPDATE User SET summery = '{summery}' WHERE email = '{email}';")
            connection.commit()

        if feature != '' and feature != None:
            cursor.execute(
                f"UPDATE Featured SET post = '{feature}' WHERE user_email = '{email}';")
            connection.commit()

        if accomplishment != '' and accomplishment != None:
            cursor.execute(
                f"UPDATE Accomplishments SET accomplishment = '{accomplishment}' WHERE user_email = '{email}';")
            connection.commit()

        last_update = datetime.datetime.now()
        cursor.execute(f"UPDATE User SET last_update = '{last_update}' WHERE email = '{email}';")
        connection.commit()
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(edit_profile_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="pale green")
        Label1.configure(font=font9)
        Label1.configure(text='''Successfully Updated.''')
        Label1.after(2000, Label1.destroy)
        connection.close()

    return

def change_password_db(password):
    email = current_email
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    if password == '' or password == None:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(signup_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''New Password is empty. Try Again.''')
        Label1.after(2000, Label1.destroy)
        change_password_db(password.get())

    last_update = datetime.datetime.now()
    # if password == None:
    #     cursor.execute(f"SELECT password FROM User WHERE email = '{email}'")
    #     password = cursor.fetchone()[0]
    # cursor.execute(f"UPDATE User SET password = '{password}', phone_number = '{phone_number}', first_name = '{first_name}', last_name = '{last_name}', birthday = '{birthday}', gender = '{gender}', location_country = '{location_country}', location_province = '{location_province}', location_city = '{location_city}', last_update = '{last_update}', image_path = '{image_path}' WHERE email = '{email}';")
    cursor.execute(f"UPDATE User SET password = '{password}', last_update = '{last_update}' WHERE email = '{email}';")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(change_password_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    # edit_profile_ui()

    return

def search_profile_db(search, search_by):
    result = []
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    search = search.capitalize()

    search_by = search_by.capitalize()
    if search_by == 'Location':
        cursor.execute(f"SELECT User.email FROM User WHERE User.location_country LIKE '%{search}%' OR User.location_city LIKE '%{search}%'")
        result = cursor.fetchone()
    elif search_by == 'en':
        cursor.execute(f"SELECT User.email FROM User WHERE User.language LIKE '{search}'")
        result = cursor.fetchone()
    elif search_by == 'per':
        cursor.execute(f"SELECT User.email FROM User WHERE User.language LIKE '{search}%'")
        result = cursor.fetchone()
    elif search_by == 'Company':
        cursor.execute(f"SELECT User.email FROM User, Experience WHERE email = user_email AND Experience.company LIKE '%{search}%' AND end_date IS NULL")
        result = cursor.fetchone()

    else:
        cursor.execute(f"SELECT User.email FROM User, Experience WHERE User.location_country LIKE '%{search}%' OR User.location_city LIKE '%{search}%' OR User.language LIKE '%{search}%' OR User.email = '%{search}%' AND Experience.company LIKE '%{search}%' AND end_date IS NULL")
        result = cursor.fetchone()

    # names_found_listbox.delete(0, tkinter.END)
    # names_found_listbox.insert(tkinter.END, f'First Name: {firstname_text}| Last Name: {lastname_text}| Speciality: {speciality_text}| Medical Council Code: {council_text}\n')

    connection.commit()
    connection.close()

    print_profile_search_result_ui(result)

    return

def add_education_db(school, degree, field, start_year, end_year, grade):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT education_id FROM Education")
    result = cursor.fetchall()
    education_id = len(result)
    cursor.execute(f"INSERt INTO Education (education_id, user_email, school, degree, field, start_year, end_year, grade) VALUES ('{education_id}', '{current_email}', '{school}', '{degree}', '{field}', '{start_year}', '{end_year}', '{grade}');")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(education_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()

    return

def delete_education_db():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"DELETE FROM Education WHERE user_email = '{current_email}' AND education_id = '{current_education_id}';")
    connection.commit()
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(show_education_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()

    return

def add_experience_db (company, job_title, start_date, end_date):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT experience_id FROM Experience")
    result = cursor.fetchall()
    experience_id = len(result)
    cursor.execute(f"INSERt INTO Experience (experience_id, user_email, company, job_title, start_date, end_date) VALUES ('{experience_id}', '{current_email}',  '{company}', '{job_title}', '{start_date}', '{end_date}')")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(experience_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()

    return

def delete_experience_db ():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"DELETE FROM Experience WHERE user_email = '{current_email}' AND experience_id = '{current_experience_id}'")
    connection.commit()
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(show_experience_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def add_skill_db(skill_id, list):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    skill_id = list[int(skill_id) - 1]
    cursor.execute(
        f"SELECT UserSkills.skill_id FROM UserSkills WHERE UserSkills.skill_id = '{skill_id}' AND UserSkills.email_user = '{current_email}'")
    result = cursor.fetchall()
    for index in range(len(result)):
        result[index] = result[index][0]
    if skill_id not in result:
        cursor.execute(
            f"INSERt INTO UserSkills (skill_id, email_user) VALUES ('{skill_id}', '{current_email}');")
        connection.commit()

        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(show_skill_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="pale green")
        Label1.configure(font=font9)
        Label1.configure(text='''Successfully Updated.''')
        Label1.after(2000, Label1.destroy)
        connection.close()
    else:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(show_skill_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Already Selected.''')
        Label1.after(2000, Label1.destroy)
        connection.close()

    return

def delete_skill_db(skill_id, list):
    connection = sqlite3.connect('Linkedin.db')
    skill_id = list[int(skill_id) - 1]
    cursor = connection.cursor()
    cursor.execute(f"DELETE FROM UserSkills WHERE email_user = '{current_email}' AND skill_id = '{skill_id}';")
    connection.commit()
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(show_my_skill_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def endorse_skill(email_endorser, email_endorsee, skill_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT Skills.id FROM Skills join User where User.email = email.endorsee")
    all_skills = cursor.fetchall()
    if skill_id not in all_skills:
        cursor.execute(f"INSERT INTO Endorsements (email_endorser, email_endorsee, skill_id) VALUES ('{email_endorser}', '{email_endorsee}', '{skill_id}')")
    connection.commit()

    global notif_list
    notif_list.append(['endorse', email_endorser, None, email_endorsee])
    connection.close()
    return

def make_network_db(email_to_me):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT connection_id FROM Connections WHERE email_me_to = '{current_email}'")
    result = cursor.fetchall()
    connection_id = len(result)
    cursor.execute(f"INSERT INTO Connections (connection_id, email_me_to, email_to_me) VALUES ('{connection_id}', '{current_email}', '{email_to_me}')")
    connection.commit()
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(recommends_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy())
    connection.close()
    return

def delete_network_db(email_index, list):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    email_index = str(list[int(email_index) - 1])
    cursor.execute(f"DELETE FROM Connections WHERE email_to_me = '{email_index}' AND email_me_to =  '{current_email}'")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(connection_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def create_direct_db(direct_id, email_sender, email_receiver):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    # print(email_sender)
    # print(email_receiver)
    # cursor.execute(f"SELECT email FROM User WHERE email = '{email_sender}'")
    # sender = cursor.fetchone()
    # print(sender[0])
    cursor.execute(f"SELECT email FROM User WHERE email = '{email_receiver}'")
    receiver = cursor.fetchone()
    # print(receiver)
    if receiver != None:
        cursor.execute(f"INSERT INTO Directs (direct_id, email_sender, email_receiver) VALUES ('{direct_id}', '{email_sender}', '{email_receiver}')")
        connection.commit()
        show_chat_ui(direct_id)

    elif receiver == None or receiver == []:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(my_directs_page)
        Label1.place(relx=0.394, rely=0.1, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='There is no Email Name as "' + email_receiver + '". Try Again.')
        Label1.after(2000, Label1.destroy)
    connection.close()


    return

def send_message_db(message_id, direct_id, email_sender, other, text):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    # print(other)
    # print(email_sender)
    cursor.execute(f"SELECT email FROM User WHERE email = '{email_sender}'")
    sender = cursor.fetchone()
    # print(sender[0])
    # cursor.execute(f"SELECT email FROM User WHERE email = '{'other'}'")
    # receiver = cursor.fetchone()
    # print(receiver)
    cursor.execute(f"SELECT direct_id FROM Directs WHERE direct_id = '{direct_id}'")
    direct = cursor.fetchone()
    message_date = datetime.datetime.now()
    # print(text)
    if sender[0] == email_sender:
        # print('khar')
        cursor.execute(
            f"INSERT INTO Messages (message_id, direct_id, email_sender, email_receiver, message_text, date_sent,media_id) VALUES ('{message_id}', '{direct[0]}', '{sender[0]}', '{other}', '{text}', '{message_date}','{'NONE'}')")
        connection.commit()
    connection.close()
    return

def delete_direct_db(direct_id, email_sender, email_receiver):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    cursor.execute(f"DELETE FROM Messages WHERE direct_id = '{direct_id}' AND email_sender = '{email_sender}' AND email_receiver = '{email_receiver}'")
    connection.commit()

    cursor.execute(f"DELETE FROM Directs WHERE direct_id = '{direct_id}' AND email_sender = '{email_sender}' AND email_receiver = '{email_receiver}'")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(my_directs_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def unread_direct_db(direct_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE Directs SET unread = '{1}' WHERE direct_id = '{direct_id}'")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(my_directs_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def delete_unread_direct_db(direct_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE Directs SET unread = '{0}' WHERE direct_id = '{direct_id}'")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(my_unread_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def archive_direct_db(direct_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE Directs SET archived = '{1}' WHERE direct_id = '{direct_id}'")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(my_directs_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def delete_archive_direct_db(direct_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"UPDATE Directs SET archived = '{0}' WHERE direct_id = '{direct_id}'")
    connection.commit()

    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    Label1 = tkinter.Label(my_archived_page)
    Label1.place(relx=0.394, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font9)
    Label1.configure(text='''Successfully Updated.''')
    Label1.after(2000, Label1.destroy)
    connection.close()
    return

def post(media, postid):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    add_post_date = datetime.datetime.now()
    # cursor.execute(f"SELECT email FROM USER WHERE  email = '{current_email}'")
    # useremail = cursor.fetchone()

    if media == '':
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(new_post_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=325)
        Label1.configure(background="tomato")
        Label1.configure(font=font9)
        Label1.configure(text='''You Can't Share a Null Post.''')
        Label1.after(3000, Label1.destroy)

    elif media != '':
        cursor.execute(
            f"INSERT INTO Posts1 (post_id, post_date, media,user_email) VALUES ('{postid}', '{add_post_date}', '{media}','{current_email}');")

        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label2 = tkinter.Label(new_post_page)
        Label2.place(relx=0.394, rely=0.31, height=24, width=315)
        Label2.configure(background="yellow green")
        Label2.configure(font=font9)
        Label2.configure(text='''Successfully Shared.''')
        Label2.after(3000, Label2.destroy)

    connection.commit()
    connection.close()
    return

def comment(post_id, comment_id, text, user_email, parent_id=None):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    # cursor.execute(f"SELECT email FROM USER WHERE  email = '{user_email}'")
    # user_cm = cursor.fetchone()
    cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}'")
    post_cm = cursor.fetchone()

    cursor.execute(f"SELECT user_email FROM Posts1 WHERE  post_id = '{post_id}'")
    post_cm2 = cursor.fetchone()

    if user_email == current_email and post_cm[0] == post_id:
        if text != '':
            cursor.execute(
            f"INSERT INTO Comments(text , comment_id , post_id ,user_email ,parent_id ) VALUES ('{text}', '{comment_id}', '{post_cm[0]}', '{current_email}', '{parent_id}' );")
            notif_list.append(['comment', current_email, post_cm[0], post_cm2[0]])
        else:
            font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
            Label1 = tkinter.Label(posts_page)
            Label1.place(relx=0.394, rely=0.31, height=24, width=315)
            Label1.configure(background="light coral")
            Label1.configure(font=font9)
            Label1.configure(text='''Empty content.''')
            Label1.after(3000, Label1.destroy)



    connection.commit()
    connection.close()
    return

def all_comment(postid):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global all_cms_page

    all_cms_page = tkinter.Tk()
    all_cms_page.title('All cms')
    all_cms_page.attributes('-fullscreen', True)
    all_cms_page.configure(background="#2d3436")

    back_button = tkinter.Button(all_cms_page, command=all_cms_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="Black")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Frame35 = tkinter.Frame(all_cms_page)
    Frame35.place(relx=0.171, rely=0.385, relheight=0.285, relwidth=0.51)
    Frame35.configure(relief='flat')
    Frame35.configure(borderwidth="2")
    Frame35.configure(background="#ffffff")

    Label1 = tkinter.Label(Frame35)
    Label1.place(relx=0.079, rely=0.110, height=24, width=129)
    Label1.configure(background="#ffffff")
    Label1.configure(font=font9)
    Label1.configure(text='''all comments : ''')

    list1 = []
    email = current_email
    cursor.execute(f"SELECT text , user_email,comment_id,parent_id FROM Comments WHERE  Comments.post_id = '{postid}';")
    list1.append(cursor.fetchall())

    Label2 = tkinter.Label(Frame35)
    Label2.place(relx=0.039, rely=0.230, height=24, width=429)
    Label2.configure(background="pink")
    Label2.configure(font=font9)
    Label2.configure(text=list1)

    Label3 = tkinter.Label(Frame35)
    Label3.place(relx=0.079, rely=0.350, height=24, width=230)
    Label3.configure(background="#ffffff")
    Label3.configure(font=font9)
    Label3.configure(text='''choose comment for like :''')

    choose_cm_entry = tkinter.Entry(Frame35)
    choose_cm_entry.place(relx=0.400, rely=0.350, height=24, relwidth=0.105)
    choose_cm_entry.configure(background="light gray")
    choose_cm_entry.configure(font=font9)
    choose_cm_entry.configure(justify='center')
    choose_cm_entry.configure(relief="flat")
    choose_cm_entry.configure(foreground="#ffffff")

    search_speciality_button = tkinter.Button(Frame35,
                                              command=lambda: like_comment(email, postid, choose_cm_entry.get()))
    search_speciality_button.place(relx=0.515, rely=0.350, height=24, width=90)
    search_speciality_button.configure(activebackground="#dfe6e9")
    search_speciality_button.configure(background="#2d3436")
    search_speciality_button.configure(font=font9)
    search_speciality_button.configure(foreground="red")
    search_speciality_button.configure(relief="flat")
    search_speciality_button.configure(text='''tab''')

    Label4 = tkinter.Label(Frame35)
    Label4.place(relx=0.079, rely=0.480, height=24, width=230)
    Label4.configure(background="#ffffff")
    Label4.configure(font=font9)
    Label4.configure(text='''choose comment for reply :''')

    choose_cm2_entry = tkinter.Entry(Frame35)
    choose_cm2_entry.place(relx=0.400, rely=0.480, height=24, relwidth=0.105)
    choose_cm2_entry.configure(background="light gray")
    choose_cm2_entry.configure(font=font9)
    choose_cm2_entry.configure(justify='center')
    choose_cm2_entry.configure(relief="flat")
    choose_cm2_entry.configure(foreground="#ffffff")

    choose_cm3_entry = tkinter.Entry(Frame35)
    choose_cm3_entry.place(relx=0.515, rely=0.480, height=24, relwidth=0.130)
    choose_cm3_entry.configure(background="light gray")
    choose_cm3_entry.configure(font=font9)
    choose_cm3_entry.configure(justify='center')
    choose_cm3_entry.configure(relief="flat")
    choose_cm3_entry.configure(foreground="black")
    choose_cm3_entry.insert(0, 'enter text')

    cursor.execute(f"select comment_id from Comments where post_id = '{postid}';")
    a = cursor.fetchall()
    a3 = len(a) + 1

    search_speciality_button = tkinter.Button(Frame35,
                                              command=lambda: comment(postid, a3 ,choose_cm3_entry.get(), current_email,
                                                                      choose_cm2_entry.get()))
    search_speciality_button.place(relx=0.650, rely=0.480, height=24, width=90)
    search_speciality_button.configure(activebackground="#dfe6e9")
    search_speciality_button.configure(background="#2d3436")
    search_speciality_button.configure(font=font9)
    search_speciality_button.configure(foreground="red")
    search_speciality_button.configure(relief="flat")
    search_speciality_button.configure(text='''tab ''')

    Label4 = tkinter.Label(Frame35)
    Label4.place(relx=0.079, rely=0.610, height=24, width=230)
    Label4.configure(background="#ffffff")
    Label4.configure(font=font9)
    Label4.configure(text='''choose your comment to delete :''')

    choose_cm4_entry = tkinter.Entry(Frame35)
    choose_cm4_entry.place(relx=0.400, rely=0.610, height=24, relwidth=0.105)
    choose_cm4_entry.configure(background="light gray")
    choose_cm4_entry.configure(font=font9)
    choose_cm4_entry.configure(justify='center')
    choose_cm4_entry.configure(relief="flat")
    choose_cm4_entry.configure(foreground="#ffffff")

    search_speciality_button = tkinter.Button(Frame35,
                                              command=lambda: delete_comment( current_email,postid, choose_cm4_entry.get()))
    search_speciality_button.place(relx=0.514, rely=0.610, height=24, width=90)
    search_speciality_button.configure(activebackground="#dfe6e9")
    search_speciality_button.configure(background="#2d3436")
    search_speciality_button.configure(font=font9)
    search_speciality_button.configure(foreground="red")
    search_speciality_button.configure(relief="flat")
    search_speciality_button.configure(text='''tab ''')

    connection.commit()
    connection.close()
    return

def like_post(user_email, post_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    cursor.execute(f"SELECT email FROM USER WHERE  email = '{user_email}';")
    user_like = cursor.fetchone()
    cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}';")
    post_like = cursor.fetchone()

    cursor.execute(f"SELECT like_id FROM LikePost WHERE  post_id = '{post_like[0]}' ;")
    post_like2 = cursor.fetchall()
    post_like2 = int(post_like2[-1][0]) + 1

    if user_like[0] == user_email and post_like[0] == post_id:
        cursor.execute(
            f"INSERT INTO LikePost (user_email, post_id ,like_id) VALUEs('{user_like[0]}', '{post_like[0]}' ,'{post_like2}' );")
        connection.commit()
    notif_list.append(['like', current_email, post_like[0], user_like[0]])
    connection.commit()
    connection.close()
    return

def like_comment(user_email, post_id, comment_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    # cursor.execute(f"SELECT email FROM USER WHERE  email = '{user_email}';")
    # user_like_cm = cursor.fetchone()
    if comment_id == '':
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(all_cms_page)
        Label1.place(relx=0.394, rely=0.41, height=24, width=215)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''enter comment id first.''')
        Label1.after(3000, Label1.destroy)
    else:

        cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}';")
        post_like_cm = cursor.fetchone()

        cursor.execute(f"SELECT comment_id FROM Comments WHERE  comment_id = '{comment_id}';")
        cm_like = cursor.fetchone()

        cursor.execute(f"select like_id from LikeComment where  post_id = '{post_like_cm[0]}' and comment_id = '{cm_like[0]}';")
        likeid = cursor.fetchall()
        likeid2 = len(likeid)

        cursor.execute(f"select user_email, post_id,  comment_id from LikeComment where comment_id = '{cm_like[0]}' and post_id = '{post_like_cm[0]}' and user_email= '{current_email}'; ")
        check_like = cursor.fetchone()

        if post_like_cm[0] == post_id:
            if check_like is None:
                cursor.execute(
                    f"INSERT INTO LikeComment (user_email, post_id, like_id,comment_id ) VALUEs ('{current_email}', '{post_like_cm[0]}', '{likeid2}' ,'{cm_like[0]}');")


                font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
                Label1 = tkinter.Label(all_cms_page)
                Label1.place(relx=0.394, rely=0.41, height=24, width=215)
                Label1.configure(background="green2")
                Label1.configure(font=font9)
                Label1.configure(text='''Succesfully Liked.''')
                Label1.after(3000,Label1.destroy)
                connection.commit()
            else:
                font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
                Label1 = tkinter.Label(all_cms_page)
                Label1.place(relx=0.394, rely=0.41, height=24, width=215)
                Label1.configure(background="light coral")
                Label1.configure(font=font9)
                Label1.configure(text='''You Liked this comment before.''')
                Label1.after(3000, Label1.destroy)
                connection.commit()



    connection.commit()
    connection.close()
    return

def share_post(direct_id, email_receiver, post_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    email_sender = current_email

    cursor.execute(f"SELECT direct_id FROM Directs WHERE  direct_id = '{direct_id}'")
    direct = cursor.fetchone()

    cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}'")
    idpost = cursor.fetchone()

    direct_message_date = datetime.datetime.now()
    if direct_id == '' or email_receiver == '':
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(posts_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Try Again.''')
        Label1.after(3000, Label1.destroy)


    elif direct[0] == direct_id:
        cursor.execute(
            f"INSERT INTO Messages (direct_id, email_sender, email_receiver ,date_sent, media_id ) VALUE ('{direct[0]}' ,'{current_email}', '{email_receiver}' , '{direct_message_date}','{idpost[0]}' )")


    elif direct[0] != direct_id :
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(login_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''User not found. Try Again.''')
        Label1.after(3000,Label1.destroy)

    connection.close()
    return

def delete_post(user_email, post_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    # cursor.execute(f"SELECT email FROM USER WHERE  email = '{user_email}'")
    # user_delete_post = user_email
    cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}'")
    post_delete = cursor.fetchone()
    cursor.execute(f"SELECT user_email FROM Posts1 WHERE  post_id = '{post_id}'")
    user_delete_post = cursor.fetchone()

    if user_email == user_delete_post[0]:
        if post_delete[0] == post_id:
            cursor.execute(f"DELETE FROM Posts1 WHERE post_id = '{post_id}'")
    elif user_email != user_delete_post[0]:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(posts_page)
        Label1.place(relx=0.394, rely=0.31, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''you cant delete this post''')
        Label1.after(3000,Label1.destroy)
        # delete_post(user_email, post_id)

    connection.commit()
    connection.close()
    return

def delete_comment(user_email, post_id, comment_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT user_email FROM Comments WHERE  comment_id = '{comment_id}'")
    user_delete_cm = cursor.fetchone()

    cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}'")
    post_delete_cm = cursor.fetchone()

    cursor.execute(f"SELECT comment_id FROM Comments WHERE  comment_id = '{comment_id}'")
    cm_delete = cursor.fetchone()

    if comment_id == '':
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(all_cms_page)
        Label1.place(relx=0.394, rely=0.41, height=24, width=215)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Empty Comment id''')
        Label1.after(3000, Label1.destroy)

    elif user_delete_cm[0] != current_email:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(all_cms_page)
        Label1.place(relx=0.394, rely=0.41, height=24, width=275)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''you cant delete this Comment''')
        Label1.after(3000, Label1.destroy)

    elif user_delete_cm[0] == current_email :
        cursor.execute(f"DELETE FROM Comments WHERE comment_id = '{comment_id}';")
    connection.commit()
    connection.close()
    return

def delete_like(user_email, post_id, like_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    cursor.execute(f"SELECT email FROM USER WHERE  email = '{user_email}'")
    user_delete_like = cursor.fetchone()

    cursor.execute(f"SELECT post_id FROM Posts1 WHERE  post_id = '{post_id}'")
    post_delete_like = cursor.fetchone()

    # cursor.execute(f"SELECT like_id FROM LikePost WHERE  like_id = '{like_id}'")

    if user_delete_like[0] == user_email and post_delete_like[0] == post_id:
        cursor.execute(f"DELETE FROM LikePost WHERE like_id = '{like_id[0]}'")
    connection.commit()
    connection.close()
    return

######################################################################################
######################################################################################
######################################################################################
######################################################################################
######################################################################################

def login_ui():

    global login_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    login_page = tkinter.Tk()
    login_page.configure(background="#2d3436")
    login_page.configure(cursor="arrow")
    login_page.title('Sign Up')
    login_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(login_page, command=login_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Login = tkinter.Frame(login_page)
    Login.place(relx=0.391, rely=0.302, relheight=0.337, relwidth=0.211)
    Login.configure(relief='flat')
    Login.configure(borderwidth="2")
    Login.configure(background="#ffffff")
    Login.configure(cursor="arrow")

    email_entry = tkinter.Entry(Login)
    email_entry.place(relx=0.101, rely=0.181, height=53, relwidth=0.825)
    email_entry.configure(background="light gray")
    email_entry.configure(font=font9)
    email_entry.configure(justify='center')
    email_entry.configure(relief="flat")
    email_entry.configure(foreground="#ffffff")
    # phone_number_entry.insert(0, 'Email Address')

    password_entry = tkinter.Entry(Login)
    password_entry.place(relx=0.101, rely=0.446, height=53, relwidth=0.825)
    password_entry.configure(background="light gray")
    password_entry.configure(font=font9)
    password_entry.configure(relief="flat")
    password_entry.configure(justify="center")
    password_entry.configure(foreground="#ffffff")
    # password_entry.insert(0, 'Password')

    Label1 = tkinter.Label(Login)
    Label1.place(relx=0.019, rely=0.105, height=24, width=329)
    Label1.configure(background="#ffffff")
    Label1.configure(font=font9)
    Label1.configure(text='''Email Address''')

    Label2 = tkinter.Label(Login)
    Label2.place(relx=0.019, rely=0.35, height=24, width=329)
    Label2.configure(background="#ffffff")
    Label2.configure(font=font9)
    Label2.configure(text='''Password''')

    # login = tkinter.Button(Login, command=lambda: login_db(email_entry.get(), password_entry.get()))
    login = tkinter.Button(Login, command=lambda : login_db(email_entry.get(), password_entry.get()))
    # login = tkinter.Button(Login, command=lambda: profilePage_ui(email_entry))
    login.place(relx=0.101, rely=0.721, height=54, width=265)
    login.configure(activebackground="#dfe6e9")
    login.configure(background="#2d3436")
    login.configure(font=font10)
    login.configure(relief="flat")
    login.configure(foreground="#ffffff")
    login.configure(text='''Login''')

    # login_page.destroy()
    return

def signup_ui():

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global signup_page


    signup_page = tkinter.Tk()
    signup_page.title('Sign Up')
    signup_page.attributes('-fullscreen', True)
    signup_page.configure(relief="ridge")
    signup_page.configure(background="#2d3436")
    signup_page.configure(cursor="arrow")

    back_button = tkinter.Button(signup_page, command=signup_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Signup = tkinter.Frame(signup_page)
    Signup.place(relx=0.391, rely=0.302, relheight=0.337, relwidth=0.211)
    Signup.configure(relief='flat')
    Signup.configure(borderwidth="2")
    Signup.configure(background="#ffffff")
    Signup.configure(cursor="arrow")

    email_entry = tkinter.Entry(Signup)
    email_entry.place(relx=0.101, rely=0.181, height=53, relwidth=0.825)
    email_entry.configure(background="light gray")
    email_entry.configure(font=font9)
    email_entry.configure(justify='center')
    email_entry.configure(relief="flat")
    email_entry.configure(foreground="#ffffff")
    # phone_number_entry.insert(0, 'Email Address')

    password_entry = tkinter.Entry(Signup)
    password_entry.place(relx=0.101, rely=0.446, height=53, relwidth=0.825)
    password_entry.configure(background="light gray")
    password_entry.configure(font=font9)
    password_entry.configure(relief="flat")
    password_entry.configure(justify="center")
    password_entry.configure(foreground="#ffffff")
    # password_entry.insert(0, 'Password')

    Label1 = tkinter.Label(Signup)
    Label1.place(relx=0.019, rely=0.105, height=24, width=329)
    Label1.configure(background="#ffffff")
    Label1.configure(font=font9)
    Label1.configure(text='''Email Address''')

    Label2 = tkinter.Label(Signup)
    Label2.place(relx=0.019, rely=0.35, height=24, width=329)
    Label2.configure(background="#ffffff")
    Label2.configure(font=font9)
    Label2.configure(text='''Password''')

    # signup_db(email_entry.get(), password_entry.get())


    signup_submit_button = tkinter.Button(Signup, command=lambda: signup_db(email_entry.get(), password_entry.get()))
    # signup_submit_button = tkinter.Button(Signup, command=lambda : profilePage_ui(email_entry))
    # signup_submit_button = tkinter.Button(Signup, command=signup_db(email_entry, password_entry))
    signup_submit_button.place(relx=0.101, rely=0.721, height=54, width=265)
    signup_submit_button.configure(activebackground="#dfe6e9")
    signup_submit_button.configure(background="#2d3436")
    signup_submit_button.configure(font=font10)
    signup_submit_button.configure(relief="flat")
    signup_submit_button.configure(text='''Sign Up''')
    signup_submit_button.configure(foreground="#ffffff")

    # signup_page.destroy()
    return

def profilePage_ui():
    global current_email
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT first_name, last_name, phone_number, gender, birthday, location_country, location_city, date_joined, last_update, language, summery FROM User WHERE email = '{current_email}'")
    name = cursor.fetchone()
    first_name = name[0]
    last_name = name[1]
    phone_number = name[2]
    gender = name[3]
    birthday = name[4]
    country = name[5]
    city = name[6]
    language = name[9]
    date_joined = name[7]
    last_update = name[8]
    summery = name[10]

    cursor.execute(
        f"SELECT post FROM Featured WHERE user_email = '{current_email}'")
    features = cursor.fetchall()
    cursor.execute(
        f"SELECT accomplishment FROM Accomplishments WHERE user_email = '{current_email}'")
    accomp = cursor.fetchall()

    if (last_name != None or last_name != '' or last_name != 'None') and (first_name != None or first_name != '' or first_name != 'None'):
        name = str(first_name) + ' ' + str(last_name)
    else:
        name = 'Welcome.'

    cursor.execute(f"SELECT SkillsList.title FROM User, SkillsList, UserSkills WHERE User.email = UserSkills.email_user AND UserSkills.skill_id = SkillsList.skill_id")
    skills = cursor.fetchall()

    global profile_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    profile_page = tkinter.Tk()
    profile_page.configure(background="#2d3436")
    profile_page.configure(cursor="arrow")
    profile_page.title('Profile Page')
    profile_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(profile_page, command=profile_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    global Profile
    Profile = tkinter.Frame(profile_page)
    Profile.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    Profile.configure(relief='flat')
    Profile.configure(borderwidth="2")
    Profile.configure(background="#ffffff")
    Profile.configure(cursor="arrow")

    Label1 = tkinter.Label(Profile)
    Label1.place(relx=0.28, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text=name)

    Label2 = tkinter.Label(Profile)
    Label2.place(relx=0.02, rely=0.07, height=24, width=100)
    Label2.configure(background="light gray")
    Label2.configure(font=font10)
    Label2.configure(text='''Email Address''')

    Label21 = tkinter.Label(Profile)
    Label21.place(relx=0.37, rely=0.07, height=24, width=250)
    Label21.configure(background="white")
    Label21.configure(font=font10)
    Label21.configure(text=current_email)

    Label3 = tkinter.Label(Profile)
    Label3.place(relx=0.02, rely=0.11, height=24, width=100)
    Label3.configure(background="light gray")
    Label3.configure(font=font10)
    Label3.configure(text='''Phone Number''')

    if phone_number == '' or phone_number == None: phone_number = 'None'
    Label31 = tkinter.Label(Profile)
    Label31.place(relx=0.37, rely=0.11, height=24, width=250)
    Label31.configure(background="white")
    Label31.configure(font=font10)
    Label31.configure(text=phone_number)

    Label4 = tkinter.Label(Profile)
    Label4.place(relx=0.02, rely=0.15, height=24, width=100)
    Label4.configure(background="light gray")
    Label4.configure(font=font10)
    Label4.configure(text='''Gender''')

    if gender == 'F':
        Label41 = tkinter.Label(Profile)
        Label41.place(relx=0.37, rely=0.15, height=24, width=250)
        Label41.configure(background="white")
        Label41.configure(font=font10)
        Label41.configure(text='''Female''')

    if gender == 'M':
        Label41 = tkinter.Label(Profile)
        Label41.place(relx=0.37, rely=0.15, height=24, width=250)
        Label41.configure(background="white")
        Label41.configure(font=font10)
        Label41.configure(text='''Male''')
    if gender != 'M' and gender != 'F':
        Label41 = tkinter.Label(Profile)
        Label41.place(relx=0.37, rely=0.15, height=24, width=250)
        Label41.configure(background="white")
        Label41.configure(font=font10)
        Label41.configure(text='''None''')

    Label5 = tkinter.Label(Profile)
    Label5.place(relx=0.02, rely=0.19, height=24, width=100)
    Label5.configure(background="light gray")
    Label5.configure(font=font10)
    Label5.configure(text='''Birthday''')

    if birthday == '' or birthday == None: birthday = 'None'
    Label51 = tkinter.Label(Profile)
    Label51.place(relx=0.37, rely=0.19, height=24, width=250)
    Label51.configure(background="white")
    Label51.configure(font=font10)
    Label51.configure(text=birthday)

    Label6 = tkinter.Label(Profile)
    Label6.place(relx=0.02, rely=0.23, height=24, width=100)
    Label6.configure(background="light gray")
    Label6.configure(font=font10)
    Label6.configure(text='''Location''')

    if (country == '' or country == None) or (city == '' or city == None): country = language = 'None'
    Label61 = tkinter.Label(Profile)
    Label61.place(relx=0.37, rely=0.23, height=24, width=250)
    Label61.configure(background="white")
    Label61.configure(font=font10)
    Label61.configure(text= str(country) + ' ' + str(city))

    Label6 = tkinter.Label(Profile)
    Label6.place(relx=0.02, rely=0.27, height=24, width=100)
    Label6.configure(background="light gray")
    Label6.configure(font=font10)
    Label6.configure(text='''Language''')

    if language == '' or language == None: language = 'None'
    elif language == 'Per': language = 'Persian'
    elif language == 'En': language = 'English'
    Label61 = tkinter.Label(Profile)
    Label61.place(relx=0.37, rely=0.27, height=24, width=250)
    Label61.configure(background="white")
    Label61.configure(font=font10)
    Label61.configure(text=str(language))

    Label7 = tkinter.Label(Profile)
    Label7.place(relx=0.02, rely=0.31, height=24, width=100)
    Label7.configure(background="light gray")
    Label7.configure(font=font10)
    Label7.configure(text='''Date Joined''')

    Label71 = tkinter.Label(Profile)
    Label71.place(relx=0.37, rely=0.31, height=24, width=250)
    Label71.configure(background="white")
    Label71.configure(font=font10)
    Label71.configure(text=date_joined)

    Label8 = tkinter.Label(Profile)
    Label8.place(relx=0.02, rely=0.35, height=24, width=100)
    Label8.configure(background="light gray")
    Label8.configure(font=font10)
    Label8.configure(text='''Last Update''')

    Label81 = tkinter.Label(Profile)
    Label81.place(relx=0.37, rely=0.35, height=24, width=250)
    Label81.configure(background="white")
    Label81.configure(font=font10)
    Label81.configure(text=last_update)
    ##########################################################

    Label99 = tkinter.Label(Profile)
    Label99.place(relx=0.02, rely=0.39, height=24, width=80)
    Label99.configure(background="white")
    Label99.configure(font=font10)
    Label99.configure(text='''Summery:''')

    Label991 = tkinter.Label(Profile)
    Label991.place(relx=0.28, rely=0.39, height=54, width=280)
    Label991.configure(background="light gray")
    Label991.configure(font=font10)
    Label991.configure(text=summery)

    Label992 = tkinter.Label(Profile)
    Label992.place(relx=0.02, rely=0.48, height=24, width=80)
    Label992.configure(background="white")
    Label992.configure(font=font10)
    Label992.configure(text='''Featured:''')

    Label9922 = tkinter.Label(Profile)
    Label9922.place(relx=0.28, rely=0.48, height=54, width=280)
    Label9922.configure(background="light gray")
    Label9922.configure(font=font10)
    Label9922.configure(text=features)

    Label993 = tkinter.Label(Profile)
    Label993.place(relx=0.01, rely=0.57, height=24, width=100)
    Label993.configure(background="white")
    Label993.configure(font=font10)
    Label993.configure(text='''Accomplished:''')

    Label993 = tkinter.Label(Profile)
    Label993.place(relx=0.28, rely=0.57, height=54, width=280)
    Label993.configure(background="light gray")
    Label993.configure(font=font10)
    Label993.configure(text=accomp)


    ##########################################################
    edit_button = tkinter.Button(Profile, command=edit_profile_ui)
    edit_button.place(relx=0.02, rely=0.68, height=24, width=150)
    edit_button.configure(activebackground="#dfe6e9")
    edit_button.configure(background="#2d3436")
    edit_button.configure(font=font9)
    edit_button.configure(relief="flat")
    edit_button.configure(text='''Edit Profile''')
    edit_button.configure(foreground="#ffffff")

    delete_profile_button = tkinter.Button(Profile, command=delete_account_ui)
    delete_profile_button.place(relx=0.61, rely=0.68, height=24, width=150)
    delete_profile_button.configure(activebackground="#dfe6e9")
    delete_profile_button.configure(background="light coral")
    delete_profile_button.configure(font=font9)
    delete_profile_button.configure(relief="flat")
    delete_profile_button.configure(text='''Delete Account''')
    delete_profile_button.configure(foreground="#ffffff")

    add_skill_button = tkinter.Button(Profile, command=show_skill_ui)
    add_skill_button.place(relx=0.02, rely=0.74, height=24, width=150)
    add_skill_button.configure(activebackground="#dfe6e9")
    add_skill_button.configure(background="#2d3436")
    add_skill_button.configure(font=font9)
    add_skill_button.configure(relief="flat")
    add_skill_button.configure(text='''Add New Skill''')
    add_skill_button.configure(foreground="#ffffff")

    show_skill_button = tkinter.Button(Profile, command=show_my_skills_ui)
    show_skill_button.place(relx=0.61, rely=0.74, height=24, width=150)
    show_skill_button.configure(activebackground="#dfe6e9")
    show_skill_button.configure(background="#2d3436")
    show_skill_button.configure(font=font9)
    show_skill_button.configure(relief="flat")
    show_skill_button.configure(text='''Show My Skills''')
    show_skill_button.configure(foreground="#ffffff")

    add_education_button = tkinter.Button(Profile, command=add_education_ui)
    add_education_button.place(relx=0.02, rely=0.8, height=24, width=150)
    add_education_button.configure(activebackground="#dfe6e9")
    add_education_button.configure(background="#2d3436")
    add_education_button.configure(font=font9)
    add_education_button.configure(relief="flat")
    add_education_button.configure(text='''Add New Education''')
    add_education_button.configure(foreground="#ffffff")

    show_education_button = tkinter.Button(Profile, command=show_education_ui)
    show_education_button.place(relx=0.61, rely=0.8, height=24, width=150)
    show_education_button.configure(activebackground="#dfe6e9")
    show_education_button.configure(background="#2d3436")
    show_education_button.configure(font=font9)
    show_education_button.configure(relief="flat")
    show_education_button.configure(text='''Show My Educations''')
    show_education_button.configure(foreground="#ffffff")

    add_experience_button = tkinter.Button(Profile, command=add_experience_ui)
    add_experience_button.place(relx=0.02, rely=0.86, height=24, width=150)
    add_experience_button.configure(activebackground="#dfe6e9")
    add_experience_button.configure(background="#2d3436")
    add_experience_button.configure(font=font9)
    add_experience_button.configure(relief="flat")
    add_experience_button.configure(text='''Add New Experience''')
    add_experience_button.configure(foreground="#ffffff")

    show_experience_button = tkinter.Button(Profile, command=show_experience_ui)
    show_experience_button.place(relx=0.61, rely=0.86, height=24, width=150)
    show_experience_button.configure(activebackground="#dfe6e9")
    show_experience_button.configure(background="#2d3436")
    show_experience_button.configure(font=font9)
    show_experience_button.configure(relief="flat")
    show_experience_button.configure(text='''Show My Experiences''')
    show_experience_button.configure(foreground="#ffffff")

    show_connections_button = tkinter.Button(Profile, command=show_connection_ui)
    show_connections_button.place(relx=0.61, rely=0.92, height=24, width=150)
    show_connections_button.configure(activebackground="#dfe6e9")
    show_connections_button.configure(background="#2d3436")
    show_connections_button.configure(font=font9)
    show_connections_button.configure(relief="flat")
    show_connections_button.configure(text='''Show My Connections''')
    show_connections_button.configure(foreground="#ffffff")

    show_connections_button = tkinter.Button(Profile, command=show_directs_ui)
    show_connections_button.place(relx=0.02, rely=0.92, height=24, width=150)
    show_connections_button.configure(activebackground="#dfe6e9")
    show_connections_button.configure(background="#2d3436")
    show_connections_button.configure(font=font9)
    show_connections_button.configure(relief="flat")
    show_connections_button.configure(text='''Directs''')
    show_connections_button.configure(foreground="#ffffff")

    return

def delete_account_ui():
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    account = tkinter.Frame(profile_page)
    account.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    account.configure(relief='flat')
    account.configure(borderwidth="2")
    account.configure(background="light coral")
    account.configure(cursor="arrow")

    Label1 = tkinter.Label(profile_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(account, command=delete_account_db)
    yes_button.place(relx=0.125, rely=0.60, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(account, command=profilePage_ui)
    cancel_button.place(relx=0.555, rely=0.60, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def edit_profile_ui():
    global current_email
    global edit_profile_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    edit_profile_page = tkinter.Tk()
    edit_profile_page.configure(background="#2d3436")
    edit_profile_page.configure(cursor="arrow")
    edit_profile_page.title('Sign Up')
    edit_profile_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(edit_profile_page, command=edit_profile_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Profile_edit = tkinter.Frame(edit_profile_page)
    Profile_edit.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    Profile_edit.configure(relief='flat')
    Profile_edit.configure(borderwidth="2")
    Profile_edit.configure(background="#ffffff")
    Profile_edit.configure(cursor="arrow")

    Label1 = tkinter.Label(Profile_edit)
    Label1.place(relx=0.28, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Edit Profile')

    ##################################
    Label2 = tkinter.Label(Profile_edit)
    Label2.place(relx=0.0, rely=0.12, height=24, width=200)
    Label2.configure(background="white")
    Label2.configure(font=font10)
    Label2.configure(text='First Name')

    first_name_entry = tkinter.Entry(Profile_edit)
    first_name_entry.place(relx=0.45, rely=0.12, height=24, relwidth=0.400)
    first_name_entry.configure(background="light gray")
    first_name_entry.configure(font=font9)
    first_name_entry.configure(relief="flat")
    first_name_entry.configure(justify="center")
    first_name_entry.configure(foreground="#ffffff")

    ##################################
    Label3 = tkinter.Label(Profile_edit)
    Label3.place(relx=0.0, rely=0.18, height=24, width=200)
    Label3.configure(background="white")
    Label3.configure(font=font10)
    Label3.configure(text='Last Name')

    last_name_entry = tkinter.Entry(Profile_edit)
    last_name_entry.place(relx=0.45, rely=0.18, height=24, relwidth=0.400)
    last_name_entry.configure(background="light gray")
    last_name_entry.configure(font=font9)
    last_name_entry.configure(relief="flat")
    last_name_entry.configure(justify="center")
    last_name_entry.configure(foreground="#ffffff")

    ##################################
    Label3 = tkinter.Label(Profile_edit)
    Label3.place(relx=0.0, rely=0.24, height=24, width=200)
    Label3.configure(background="white")
    Label3.configure(font=font10)
    Label3.configure(text='Phone Number')

    phone_number_entry = tkinter.Entry(Profile_edit)
    phone_number_entry.place(relx=0.45, rely=0.24, height=24, relwidth=0.400)
    phone_number_entry.configure(background="light gray")
    phone_number_entry.configure(font=font9)
    phone_number_entry.configure(relief="flat")
    phone_number_entry.configure(justify="center")
    phone_number_entry.configure(foreground="#ffffff")

    ##################################
    Label4 = tkinter.Label(Profile_edit)
    Label4.place(relx=0.0, rely=0.30, height=24, width=200)
    Label4.configure(background="white")
    Label4.configure(font=font10)
    Label4.configure(text='Gender (F/M)')

    gender_entry = tkinter.Entry(Profile_edit)
    gender_entry.place(relx=0.45, rely=0.30, height=24, relwidth=0.400)
    gender_entry.configure(background="light gray")
    gender_entry.configure(font=font9)
    gender_entry.configure(relief="flat")
    gender_entry.configure(justify="center")
    gender_entry.configure(foreground="#ffffff")

    ##################################
    Label5 = tkinter.Label(Profile_edit)
    Label5.place(relx=0.0, rely=0.36, height=24, width=200)
    Label5.configure(background="white")
    Label5.configure(font=font10)
    Label5.configure(text='Birthday')

    birthday_entry = tkinter.Entry(Profile_edit)
    birthday_entry.place(relx=0.45, rely=0.36, height=24, relwidth=0.400)
    birthday_entry.configure(background="light gray")
    birthday_entry.configure(font=font9)
    birthday_entry.configure(relief="flat")
    birthday_entry.configure(justify="center")
    birthday_entry.configure(foreground="#ffffff")

    ##################################
    Label6 = tkinter.Label(Profile_edit)
    Label6.place(relx=0.0, rely=0.42, height=24, width=200)
    Label6.configure(background="white")
    Label6.configure(font=font10)
    Label6.configure(text='Country')

    location_country_entry = tkinter.Entry(Profile_edit)
    location_country_entry.place(relx=0.45, rely=0.42, height=24, relwidth=0.400)
    location_country_entry.configure(background="light gray")
    location_country_entry.configure(font=font9)
    location_country_entry.configure(relief="flat")
    location_country_entry.configure(justify="center")
    location_country_entry.configure(foreground="#ffffff")

    ##################################
    Label8 = tkinter.Label(Profile_edit)
    Label8.place(relx=0.0, rely=0.48, height=24, width=200)
    Label8.configure(background="white")
    Label8.configure(font=font10)
    Label8.configure(text='City')

    location_city_entry = tkinter.Entry(Profile_edit)
    location_city_entry.place(relx=0.45, rely=0.48, height=24, relwidth=0.400)
    location_city_entry.configure(background="light gray")
    location_city_entry.configure(font=font9)
    location_city_entry.configure(relief="flat")
    location_city_entry.configure(justify="center")
    location_city_entry.configure(foreground="#ffffff")

    ##################################
    Label9 = tkinter.Label(Profile_edit)
    Label9.place(relx=0.0, rely=0.53, height=24, width=200)
    Label9.configure(background="white")
    Label9.configure(font=font10)
    Label9.configure(text='Language (en / per)')

    language_entry = tkinter.Entry(Profile_edit)
    language_entry.place(relx=0.45, rely=0.53, height=24, relwidth=0.400)
    language_entry.configure(background="light gray")
    language_entry.configure(font=font9)
    language_entry.configure(relief="flat")
    language_entry.configure(justify="center")
    language_entry.configure(foreground="#ffffff")
    ##################################

    Label91 = tkinter.Label(Profile_edit)
    Label91.place(relx=0.0, rely=0.58, height=24, width=200)
    Label91.configure(background="white")
    Label91.configure(font=font10)
    Label91.configure(text='Summery')

    summery_entry = tkinter.Entry(Profile_edit)
    summery_entry.place(relx=0.45, rely=0.58, height=54, relwidth=0.400)
    summery_entry.configure(background="light gray")
    summery_entry.configure(font=font9)
    summery_entry.configure(relief="flat")
    summery_entry.configure(justify="center")
    summery_entry.configure(foreground="#ffffff")

    Label92 = tkinter.Label(Profile_edit)
    Label92.place(relx=0.0, rely=0.67, height=24, width=200)
    Label92.configure(background="white")
    Label92.configure(font=font10)
    Label92.configure(text='Featured')

    featured_entry = tkinter.Entry(Profile_edit)
    featured_entry.place(relx=0.45, rely=0.67, height=54, relwidth=0.400)
    featured_entry.configure(background="light gray")
    featured_entry.configure(font=font9)
    featured_entry.configure(relief="flat")
    featured_entry.configure(justify="center")
    featured_entry.configure(foreground="#ffffff")

    Label93 = tkinter.Label(Profile_edit)
    Label93.place(relx=0.0, rely=0.76, height=24, width=200)
    Label93.configure(background="white")
    Label93.configure(font=font10)
    Label93.configure(text='Accomplishment')

    accompli_entry = tkinter.Entry(Profile_edit)
    accompli_entry.place(relx=0.45, rely=0.76, height=54, relwidth=0.400)
    accompli_entry.configure(background="light gray")
    accompli_entry.configure(relief="flat")
    accompli_entry.configure(font=font9)
    accompli_entry.configure(justify="center")
    accompli_entry.configure(foreground="#ffffff")


    ##################################
    save_button = tkinter.Button(Profile_edit, command=lambda: edit_profile_db(current_email, phone_number_entry.get(), first_name_entry.get(), last_name_entry.get(), gender_entry.get(), birthday_entry.get(), location_country_entry.get(), location_city_entry.get(), language_entry.get(), summery_entry.get(), featured_entry.get(), accompli_entry.get()))
    save_button.place(relx=0.13, rely=0.86, height=24, width=310)
    save_button.configure(activebackground="#dfe6e9")
    save_button.configure(background="#2d3436")
    save_button.configure(font=font9)
    save_button.configure(relief="flat")
    save_button.configure(text='''Save''')
    save_button.configure(foreground="#ffffff")

    password_button = tkinter.Button(Profile_edit, command=change_password_ui)
    password_button.place(relx=0.13, rely=0.92, height=24, width=310)
    password_button.configure(activebackground="#dfe6e9")
    password_button.configure(background="#2d3436")
    password_button.configure(font=font9)
    password_button.configure(relief="flat")
    password_button.configure(text='''Change Password''')
    password_button.configure(foreground="#ffffff")


    return

def show_directs_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT direct_id, email_receiver FROM Directs, User WHERE User.email = Directs.email_sender AND User.email = '{current_email}'")
    users = cursor.fetchall()
    direct_ids = []
    user_receivers = []
    for item in users:
        direct_ids.append(item[0])
        user_receivers.append(item[1])

    cursor.execute(
        f"SELECT direct_id, email_sender FROM Directs, User WHERE User.email = Directs.email_receiver AND User.email = '{current_email}'")
    users2 = cursor.fetchall()
    for item in users2:
        direct_ids.append(item[0])
        user_receivers.append(item[1])

    name = []
    receiver_first = []
    receiver_last = []
    for user in user_receivers:
        cursor.execute(f"SELECT first_name, last_name FROM User WHERE email = '{user}'")
        name = cursor.fetchone()
        if name != []:
            receiver_first.append(name[0])
            receiver_last.append(name[1])

    global my_directs_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    my_directs_page = tkinter.Tk()
    my_directs_page.configure(background="#2d3436")
    my_directs_page.configure(cursor="arrow")
    my_directs_page.title('Directs Page')
    my_directs_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(my_directs_page, command=my_directs_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    my_directs = tkinter.Frame(my_directs_page)
    my_directs.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    my_directs.configure(relief='flat')
    my_directs.configure(borderwidth="2")
    my_directs.configure(background="#ffffff")
    my_directs.configure(cursor="arrow")

    Label1 = tkinter.Label(my_directs)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Directs')

    Label40 = tkinter.Label(my_directs)
    Label40.place(relx=0.12, rely=0.9, height=24, relwidth=0.490)
    Label40.configure(background="white")
    Label40.configure(font=font9)
    Label40.configure(text='Enter user email for new chat :')

    newww_entry = tkinter.Entry(my_directs)
    newww_entry.place(relx=0.500, rely=0.9, height=24, relwidth=0.230)
    newww_entry.configure(background="dark gray")
    newww_entry.configure(font=font9)
    newww_entry.configure(relief="raised")
    newww_entry.configure(justify="center")
    newww_entry.configure(foreground="#ffffff")

    cursor.execute(f"select direct_id from Directs")
    dcid_get = cursor.fetchall()
    dcid = len(dcid_get)

    create_dc_button = tkinter.Button(my_directs, command=lambda: create_direct_db(dcid, current_email, newww_entry.get()))
    create_dc_button.place(relx=0.750, rely=0.90, height=24, width=60)
    create_dc_button.configure(activebackground="#dfe6e9")
    create_dc_button.configure(background="#2d3436")
    create_dc_button.configure(font=font9)
    create_dc_button.configure(relief="flat")
    create_dc_button.configure(foreground="white")
    create_dc_button.configure(text='''Create''')



    global current_direct_id
    global current_receiver_first
    global current_receiver_last
    if name == None or name == []:
        Label1 = tkinter.Label(my_directs_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')


    else:
        unread_button = tkinter.Button(my_directs, command=show_unread_directs_ui)
        unread_button.place(relx=0.8, rely=0.053, height=24, width=150)
        unread_button.configure(activebackground="#dfe6e9")
        unread_button.configure(background="#2d3436")
        unread_button.configure(font=font9)
        unread_button.configure(relief="flat")
        unread_button.configure(text='''Show Unread Directs''')
        unread_button.configure(foreground="#ffffff")

        archive_button = tkinter.Button(my_directs, command=show_archived_directs_ui)
        archive_button.place(relx=0.8, rely=0.103, height=24, width=150)
        archive_button.configure(activebackground="#dfe6e9")
        archive_button.configure(background="#2d3436")
        archive_button.configure(font=font9)
        archive_button.configure(relief="flat")
        archive_button.configure(text='''Show Archive Directs''')
        archive_button.configure(foreground="#ffffff")

        rel_y = 0.215
        rel_y2 = 0.153

        for index in range(len(receiver_first)):
            current_direct_id = direct_ids[index]
            current_receiver_first = receiver_first[index]
            current_receiver_last = receiver_last[index]

            Label6 = tkinter.Label(my_directs_page)
            Label6.place(relx=0.205, rely=rel_y, height=24, width=180)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=receiver_first[index] + ' ' + receiver_last[index])

            show_button = tkinter.Button(my_directs, command=lambda: show_chat_ui(direct_ids[index]))
            show_button.place(relx=0.215, rely=rel_y2, height=24, width=80)
            show_button.configure(activebackground="#dfe6e9")
            show_button.configure(background="gray")
            show_button.configure(font=font9)
            show_button.configure(relief="flat")
            show_button.configure(text='''Show''')
            show_button.configure(foreground="#ffffff")

            delete_button = tkinter.Button(my_directs, command=lambda: delete_direct_ui(current_direct_id, current_email, user_receivers[index]))
            delete_button.place(relx=0.315, rely=rel_y2, height=24, width=80)
            delete_button.configure(activebackground="#dfe6e9")
            delete_button.configure(background="gray")
            delete_button.configure(font=font9)
            delete_button.configure(relief="flat")
            delete_button.configure(text='''Delete''')
            delete_button.configure(foreground="#ffffff")

            cursor.execute(f"SELECT unread FROM Directs WHERE direct_id = '{current_direct_id}'")
            unread_flag = cursor.fetchone()[0]

            status = ''
            if unread_flag == 1:
                status = "Delete from Unreads"

                unread_button = tkinter.Button(my_directs, command=lambda: delete_unread_direct_db(current_direct_id))
                unread_button.place(relx=0.415, rely=rel_y2, height=24, width=150)
                unread_button.configure(activebackground="#dfe6e9")
                unread_button.configure(background="gray")
                unread_button.configure(font=font9)
                unread_button.configure(relief="flat")
                unread_button.configure(text=status)
                unread_button.configure(foreground="#ffffff")

            if unread_flag == 0 or unread_flag == None:
                status = "Mark as Unread"

                unread_button = tkinter.Button(my_directs, command=lambda: unread_direct_db(current_direct_id))
                unread_button.place(relx=0.415, rely=rel_y2, height=24, width=150)
                unread_button.configure(activebackground="#dfe6e9")
                unread_button.configure(background="gray")
                unread_button.configure(font=font9)
                unread_button.configure(relief="flat")
                unread_button.configure(text=status)
                unread_button.configure(foreground="#ffffff")

            cursor.execute(f"SELECT archived FROM Directs WHERE direct_id = '{current_direct_id}'")
            archived_flag = cursor.fetchone()[0]

            if archived_flag == 1:
                status = "Delete from Archives"

                archive_button = tkinter.Button(my_directs, command=lambda: delete_archive_direct_db(current_direct_id))
                archive_button.place(relx=0.595, rely=rel_y2, height=24, width=150)
                archive_button.configure(activebackground="#dfe6e9")
                archive_button.configure(background="gray")
                archive_button.configure(font=font9)
                archive_button.configure(relief="flat")
                archive_button.configure(text=status)
                archive_button.configure(foreground="#ffffff")

            if archived_flag == 0 or archived_flag == None:
                status = "Archive Direct"

                archive_button = tkinter.Button(my_directs, command=lambda: archive_direct_db(current_direct_id))
                archive_button.place(relx=0.595, rely=rel_y2, height=24, width=150)
                archive_button.configure(activebackground="#dfe6e9")
                archive_button.configure(background="gray")
                archive_button.configure(font=font9)
                archive_button.configure(relief="flat")
                archive_button.configure(text=status)
                archive_button.configure(foreground="#ffffff")

            rel_y += 0.5
            rel_y2 += 0.5
    connection.close()
    return

def delete_direct_ui(direct_id, sender, receiver):
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    my_directs = tkinter.Frame(my_directs_page)
    my_directs.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    my_directs.configure(relief='flat')
    my_directs.configure(borderwidth="2")
    my_directs.configure(background="light coral")
    my_directs.configure(cursor="arrow")

    Label1 = tkinter.Label(my_directs_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(my_directs, command=lambda: delete_direct_db(direct_id, sender, receiver))
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(my_directs, command=show_directs_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def show_unread_directs_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT direct_id, email_receiver FROM Directs, User WHERE User.email = Directs.email_sender AND Directs.unread = '{1}'")
    users = cursor.fetchall()
    direct_ids = []
    user_receivers = []
    for item in users:
        direct_ids.append(item[0])
        user_receivers.append(item[1])

    receiver_first = []
    receiver_last = []
    for user in user_receivers:
        cursor.execute(f"SELECT first_name, last_name FROM User WHERE email = '{user}'")
        name = cursor.fetchone()
        receiver_first.append(name[0])
        receiver_last.append(name[1])

    global my_unread_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    my_unread_page = tkinter.Tk()
    my_unread_page.configure(background="#2d3436")
    my_unread_page.configure(cursor="arrow")
    my_unread_page.title('Profile Page')
    my_unread_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(my_unread_page, command=my_unread_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    my_unread = tkinter.Frame(my_unread_page)
    my_unread.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    my_unread.configure(relief='flat')
    my_unread.configure(borderwidth="2")
    my_unread.configure(background="#ffffff")
    my_unread.configure(cursor="arrow")

    Label1 = tkinter.Label(my_unread)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Unread Directs')

    if direct_ids == []:
        Label1 = tkinter.Label(my_unread_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        rel_y = 0.20
        rel_y2 = 0.133
        for index in range(len(receiver_first)):
            Label6 = tkinter.Label(my_unread_page)
            Label6.place(relx=0.205, rely=rel_y, height=24, width=180)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=current_receiver_first + ' ' + current_receiver_last)

            show_button = tkinter.Button(my_unread, command=add_education_ui)
            show_button.place(relx=0.215, rely=rel_y2, height=24, width=80)
            show_button.configure(activebackground="#dfe6e9")
            show_button.configure(background="gray")
            show_button.configure(font=font9)
            show_button.configure(relief="flat")
            show_button.configure(text='''Show''')
            show_button.configure(foreground="#ffffff")

            delete_button = tkinter.Button(my_unread, command=lambda: delete_direct2_ui(current_direct_id, current_email, user_receivers[index]))
            delete_button.place(relx=0.315, rely=rel_y2, height=24, width=80)
            delete_button.configure(activebackground="#dfe6e9")
            delete_button.configure(background="gray")
            delete_button.configure(font=font9)
            delete_button.configure(relief="flat")
            delete_button.configure(text='''Delete''')
            delete_button.configure(foreground="#ffffff")

            unread_button = tkinter.Button(my_unread, command=lambda: delete_unread_direct_db(current_direct_id))
            unread_button.place(relx=0.415, rely=rel_y2, height=24, width=150)
            unread_button.configure(activebackground="#dfe6e9")
            unread_button.configure(background="gray")
            unread_button.configure(font=font9)
            unread_button.configure(relief="flat")
            unread_button.configure(text='''Delete from Unreads''')
            unread_button.configure(foreground="#ffffff")

            connection.close()


            rel_y += 0.5
            rel_y2 += 0.5
    return

def delete_direct2_ui(direct_id, sender, receiver):
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    my_unread = tkinter.Frame(my_unread_page)
    my_unread.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    my_unread.configure(relief='flat')
    my_unread.configure(borderwidth="2")
    my_unread.configure(background="light coral")
    my_unread.configure(cursor="arrow")

    Label1 = tkinter.Label(my_unread_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(my_unread, command=lambda: delete_direct_db(direct_id, sender, receiver))
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(my_unread, command=show_directs_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def show_archived_directs_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT direct_id, email_receiver FROM Directs, User WHERE User.email = Directs.email_sender AND Directs.archived = '{1}'")
    users = cursor.fetchall()
    direct_ids = []
    user_receivers = []
    for item in users:
        direct_ids.append(item[0])
        user_receivers.append(item[1])

    receiver_first = []
    receiver_last = []
    for user in user_receivers:
        cursor.execute(f"SELECT first_name, last_name FROM User WHERE email = '{user}'")
        name = cursor.fetchone()
        receiver_first.append(name[0])
        receiver_last.append(name[1])

    global my_archived_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    my_archived_page = tkinter.Tk()
    my_archived_page.configure(background="#2d3436")
    my_archived_page.configure(cursor="arrow")
    my_archived_page.title('Profile Page')
    my_archived_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(my_archived_page, command=my_archived_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    my_archives = tkinter.Frame(my_archived_page)
    my_archives.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    my_archives.configure(relief='flat')
    my_archives.configure(borderwidth="2")
    my_archives.configure(background="#ffffff")
    my_archives.configure(cursor="arrow")

    Label1 = tkinter.Label(my_archives)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Archived Directs')

    if direct_ids == []:
        Label1 = tkinter.Label(my_archived_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        rel_y = 0.20
        rel_y2 = 0.133
        for index in range(len(receiver_first)):
            Label6 = tkinter.Label(my_archived_page)
            Label6.place(relx=0.205, rely=rel_y, height=24, width=180)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=current_receiver_first + ' ' + current_receiver_last)

            show_button = tkinter.Button(my_archives, command=add_education_ui)
            show_button.place(relx=0.215, rely=rel_y2, height=24, width=80)
            show_button.configure(activebackground="#dfe6e9")
            show_button.configure(background="gray")
            show_button.configure(font=font9)
            show_button.configure(relief="flat")
            show_button.configure(text='''Show''')
            show_button.configure(foreground="#ffffff")

            delete_button = tkinter.Button(my_archives, command=lambda: delete_direct3_ui(current_direct_id, current_email, user_receivers[index]))
            delete_button.place(relx=0.315, rely=rel_y2, height=24, width=80)
            delete_button.configure(activebackground="#dfe6e9")
            delete_button.configure(background="gray")
            delete_button.configure(font=font9)
            delete_button.configure(relief="flat")
            delete_button.configure(text='''Delete''')
            delete_button.configure(foreground="#ffffff")

            unread_button = tkinter.Button(my_archives, command=lambda: delete_archive_direct_db(current_direct_id))
            unread_button.place(relx=0.415, rely=rel_y2, height=24, width=150)
            unread_button.configure(activebackground="#dfe6e9")
            unread_button.configure(background="gray")
            unread_button.configure(font=font9)
            unread_button.configure(relief="flat")
            unread_button.configure(text='''Delete from Archives''')
            unread_button.configure(foreground="#ffffff")

            connection.close()

            rel_y += 0.5
            rel_y2 += 0.5
    return

def delete_direct3_ui(direct_id, sender, receiver):
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    my_archived = tkinter.Frame(my_unread_page)
    my_archived.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    my_archived.configure(relief='flat')
    my_archived.configure(borderwidth="2")
    my_archived.configure(background="light coral")
    my_archived.configure(cursor="arrow")

    Label1 = tkinter.Label(my_archived_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(my_archived, command=lambda: delete_direct_db(direct_id, sender, receiver))
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(my_archived, command=show_directs_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def show_my_skills_ui():
    global show_my_skill_page
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_my_skill_page = tkinter.Tk()
    show_my_skill_page.configure(background="#2d3436")
    show_my_skill_page.configure(cursor="arrow")
    show_my_skill_page.title('Skill Page')
    show_my_skill_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_my_skill_page, command=show_my_skill_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    my_skill = tkinter.Frame(show_my_skill_page)
    my_skill.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    my_skill.configure(relief='flat')
    my_skill.configure(borderwidth="2")
    my_skill.configure(background="#ffffff")
    my_skill.configure(cursor="arrow")

    Label1 = tkinter.Label(my_skill)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="My Skills Page")

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT SkillsList.skill_id, SkillsList.title FROM User, UserSkills, SkillsList WHERE SkillsList.skill_id = UserSkills.skill_id AND UserSkills.email_user = User.email AND User.email = '{current_email}'")
    result = cursor.fetchall()
    ids = []
    titles = []

    for index in range(len(result)):
        ids.append(result[index][0])
        titles.append(result[index][1])

    edit_button = tkinter.Button(my_skill, command=show_skill_ui)
    edit_button.place(relx=0.80, rely=0.02, height=24, width=150)
    edit_button.configure(activebackground="#dfe6e9")
    edit_button.configure(background="#2d3436")
    edit_button.configure(font=font9)
    edit_button.configure(relief="flat")
    edit_button.configure(text='''Add New Skill''')
    edit_button.configure(foreground="#ffffff")

    rel_y = 0.09
    endorsers =[]
    if titles == []:
        Label1 = tkinter.Label(show_my_skill_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        for index in range(len(titles)):
            cursor.execute(f"SELECT DISTINCT User.first_name, User.last_name FROM Endorsements, User WHERE Endorsements.skill_id = '{ids[index-1]}'")
            list = cursor.fetchall()
            for item in list:
                endorsers.append(item[0]+ ' ' + item[1])

            Label2 = tkinter.Label(my_skill)
            Label2.place(relx=0.07, rely=rel_y, height=24, width=30)
            Label2.configure(background="gray")
            Label2.configure(font=font10)
            Label2.configure(text=index + 1)

            Label3 = tkinter.Label(my_skill)
            Label3.place(relx=0.10, rely=rel_y, height=24, width=300)
            Label3.configure(background="white")
            Label3.configure(font=font10)
            Label3.configure(text=titles[index])

            if len(endorsers) > 5:
                Label4 = tkinter.Label(my_skill)
                Label4.place(relx=0.12, rely=rel_y+0.05, height=35, width=470)
                Label4.configure(background="white")
                Label4.configure(font=font10)
                Label4.configure(text=str(endorsers[:5]))
            if len(endorsers) < 5:
                Label4 = tkinter.Label(my_skill)
                Label4.place(relx=0.12, rely=rel_y+0.05, height=3, width=470)
                Label4.configure(background="white")
                Label4.configure(font=font10)
                Label4.configure(text=str(endorsers))
            if endorsers == []:
                Label4 = tkinter.Label(my_skill)
                Label4.place(relx=0.12, rely=rel_y + 0.05, height=35, width=470)
                Label4.configure(background="light gray")
                Label4.configure(font=font10)
                Label4.configure(text="Nobody Endorse this Skill.")

            rel_y += 0.15

        Label2 = tkinter.Label(my_skill)
        Label2.place(relx=0.25, rely=0.88, height=24, width=280)
        Label2.configure(background="white")
        Label2.configure(font=font10)
        Label2.configure(text='Which Number Do You Want to Delete?')

        choice_entry = tkinter.Entry(my_skill)
        choice_entry.place(relx=0.57, rely=0.88, height=24, relwidth=0.04)
        choice_entry.configure(background="light gray")
        choice_entry.configure(font=font9)
        choice_entry.configure(relief="flat")
        choice_entry.configure(justify="center")
        choice_entry.configure(foreground="#ffffff")

        delete_button = tkinter.Button(my_skill, command=lambda:delete_skill_ui(choice_entry.get(), ids))
        delete_button.place(relx=0.64, rely=0.88, height=24, width=90)
        delete_button.configure(activebackground="#dfe6e9")
        delete_button.configure(background="#2d3436")
        delete_button.configure(font=font9)
        delete_button.configure(relief="flat")
        delete_button.configure(text='''Delete Skill''')
        delete_button.configure(foreground="#ffffff")

    return

def show_skill_ui():
    global show_skill_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_skill_page = tkinter.Tk()
    show_skill_page.configure(background="#2d3436")
    show_skill_page.configure(cursor="arrow")
    show_skill_page.title('Skill Page')
    show_skill_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_skill_page, command=show_skill_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    global skill
    skill = tkinter.Frame(show_skill_page)
    skill.place(relx=0.3, rely=0.092, relheight=0.807, relwidth=0.40)
    skill.configure(relief='flat')
    skill.configure(borderwidth="2")
    skill.configure(background="#ffffff")
    skill.configure(cursor="arrow")

    ##################################
    Label1 = tkinter.Label(skill)
    Label1.place(relx=0.02, rely=0.05, height=24, width=150)
    Label1.configure(background="white")
    Label1.configure(font=font10)
    Label1.configure(text='Search ...')

    test_entry = tkinter.Entry(skill)
    test_entry.place(relx=0.27, rely=0.05, height=24, relwidth=0.300)
    test_entry.configure(background="light gray")
    test_entry.configure(font=font9)
    test_entry.configure(relief="flat")
    test_entry.configure(justify="center")
    test_entry.configure(foreground="#ffffff")

    search_button = tkinter.Button(skill, command=lambda: print_skill_result(test_entry.get()))
    search_button.place(relx=0.6, rely=0.05, height=24, width=71)
    search_button.configure(activeforeground="#2d3436")
    search_button.configure(background="#2d3436")
    search_button.configure(font=font9)
    search_button.configure(foreground="#ffffff")
    search_button.configure(relief="flat")
    search_button.configure(text='Search')

    return

def print_skill_result(search):
    search = search.capitalize()
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT SkillsList.skill_id, SkillsList.title FROM SkillsList WHERE SkillsList.title LIKE '%{search}%'")
    result = cursor.fetchall()
    ids = []
    titles = []
    for index in range(len(result)):
        ids.append(result[index][0])
        titles.append(result[index][1])

    rel_y = 0.16
    if titles == []:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(show_skill_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''No Results Found.''')
        connection.close()
    else:
        for index in range(len(titles)):
            Label2 = tkinter.Label(skill)
            Label2.place(relx=0.10, rely=rel_y, height=24, width=30)
            Label2.configure(background="gray")
            Label2.configure(font=font10)
            Label2.configure(text=index+1)

            Label3 = tkinter.Label(skill)
            Label3.place(relx=0.15, rely=rel_y, height=24, width=300)
            Label3.configure(background="white")
            Label3.configure(font=font10)
            Label3.configure(text=titles[index])

            rel_y += 0.05

        Label4 = tkinter.Label(skill)
        Label4.place(relx=0.05, rely=0.1, height = 24, width = 280)
        Label4.configure(background="white")
        Label4.configure(font=font10)
        Label4.configure(text='Which Number Do You Want to Add?')

        choice_entry = tkinter.Entry(skill)
        choice_entry.place(relx=0.5, rely=0.1, height=24, relwidth=0.04)
        choice_entry.configure(background="light gray")
        choice_entry.configure(font=font9)
        choice_entry.configure(relief="flat")
        choice_entry.configure(justify="center")
        choice_entry.configure(foreground="#ffffff")

        add_button = tkinter.Button(skill, command=lambda: add_skill_db(choice_entry.get(), ids))
        add_button.place(relx=0.57, rely=0.1, height=24, width=90)
        add_button.configure(activebackground="#dfe6e9")
        add_button.configure(background="#2d3436")
        add_button.configure(font=font9)
        add_button.configure(relief="flat")
        add_button.configure(text='''Add Skill''')
        add_button.configure(foreground="#ffffff")

    return

def delete_skill_ui(skill_id, list):
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    skill = tkinter.Frame(show_my_skill_page)
    skill.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    skill.configure(relief='flat')
    skill.configure(borderwidth="2")
    skill.configure(background="light coral")
    skill.configure(cursor="arrow")

    Label1 = tkinter.Label(show_my_skill_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(skill, command=lambda:delete_skill_db(skill_id, list))
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(skill, command=show_my_skills_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def show_education_ui():
    global show_education_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_education_page = tkinter.Tk()
    show_education_page.configure(background="#2d3436")
    show_education_page.configure(cursor="arrow")
    show_education_page.title('Education Page')
    show_education_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_education_page, command=show_education_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    education = tkinter.Frame(show_education_page)
    education.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    education.configure(relief='flat')
    education.configure(borderwidth="2")
    education.configure(background="#ffffff")
    education.configure(cursor="arrow")

    Label1 = tkinter.Label(education)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Educations Page")

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT Education.education_id, Education.school, Education.degree, Education.start_year, Education.end_year FROM User, Education WHERE Education.user_email = User.email AND User.email = '{current_email}'")
    educations = cursor.fetchall()
    ids = []
    schools = []
    degrees = []
    start = []
    end = []
    for index in range(len(educations)):
        ids.append(educations[index][0])
        schools.append(educations[index][1])
        degrees.append(educations[index][2])
        start.append(educations[index][3])
        end.append(educations[index][4])

    edit_button = tkinter.Button(education, command=add_education_ui)
    edit_button.place(relx=0.80, rely=0.02, height=24, width=150)
    edit_button.configure(activebackground="#dfe6e9")
    edit_button.configure(background="#2d3436")
    edit_button.configure(font=font9)
    edit_button.configure(relief="flat")
    edit_button.configure(text='''Add Education''')
    edit_button.configure(foreground="#ffffff")


    rel_y = 0.25
    rel_y2 = 0.19
    if schools == [] and degrees == []:
        Label1 = tkinter.Label(show_education_page)
        Label1.place(relx=0.38, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        Label2 = tkinter.Label(show_education_page)
        Label2.place(relx=0.21, rely=0.20, height=24, width=80)
        Label2.configure(background="light gray")
        Label2.configure(font=font10)
        Label2.configure(text="School")

        Label3 = tkinter.Label(show_education_page)
        Label3.place(relx=0.31, rely=0.20, height=24, width=80)
        Label3.configure(background="light gray")
        Label3.configure(font=font10)
        Label3.configure(text="Degree")

        Label4 = tkinter.Label(show_education_page)
        Label4.place(relx=0.39, rely=0.20, height=24, width=80)
        Label4.configure(background="light gray")
        Label4.configure(font=font10)
        Label4.configure(text="Start Year")

        Label5 = tkinter.Label(show_education_page)
        Label5.place(relx=0.47, rely=0.20, height=24, width=80)
        Label5.configure(background="light gray")
        Label5.configure(font=font10)
        Label5.configure(text="End Year")

        global current_education_id

        for index in range(len(schools)):
            current_education_id = ids[index]
            Label6 = tkinter.Label(show_education_page)
            Label6.place(relx=0.21, rely=rel_y, height=24, width=120)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=schools[index])

            Label7 = tkinter.Label(show_education_page)
            Label7.place(relx=0.31, rely=rel_y, height=24, width=80)
            Label7.configure(background="white")
            Label7.configure(font=font10)
            Label7.configure(text=degrees[index])

            Label8 = tkinter.Label(show_education_page)
            Label8.place(relx=0.39, rely=rel_y, height=24, width=80)
            Label8.configure(background="white")
            Label8.configure(font=font10)
            Label8.configure(text=start[index])

            Label9 = tkinter.Label(show_education_page)
            Label9.place(relx=0.47, rely=rel_y, height=24, width=80)
            Label9.configure(background="white")
            Label9.configure(font=font10)
            Label9.configure(text=end[index])

            delete_button = tkinter.Button(education, command=delete_education_ui)
            delete_button.place(relx=0.63, rely=rel_y2, height=24, width=150)
            delete_button.configure(activebackground="#dfe6e9")
            delete_button.configure(background="#2d3436")
            delete_button.configure(font=font9)
            delete_button.configure(relief="flat")
            delete_button.configure(text='''Delete Education''')
            delete_button.configure(foreground="#ffffff")

            rel_y += 0.05
            rel_y2 += 0.06
    return

def add_education_ui():

    global education_page
    global education
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    education_page = tkinter.Tk()
    education_page.configure(background="#2d3436")
    education_page.configure(cursor="arrow")
    education_page.title('Education Page')
    education_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(education_page, command=education_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    education = tkinter.Frame(education_page)
    education.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    education.configure(relief='flat')
    education.configure(borderwidth="2")
    education.configure(background="#ffffff")
    education.configure(cursor="arrow")

    Label1 = tkinter.Label(education)
    Label1.place(relx=0.28, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Add Education')

    ##################################
    Label2 = tkinter.Label(education)
    Label2.place(relx=0.02, rely=0.12, height=24, width=150)
    Label2.configure(background="white")
    Label2.configure(font=font10)
    Label2.configure(text='School')

    school_entry = tkinter.Entry(education)
    school_entry.place(relx=0.52, rely=0.12, height=24, relwidth=0.400)
    school_entry.configure(background="light gray")
    school_entry.configure(font=font9)
    school_entry.configure(relief="flat")
    school_entry.configure(justify="center")
    school_entry.configure(foreground="#ffffff")

    ##################################
    Label3 = tkinter.Label(education)
    Label3.place(relx=0.02, rely=0.18, height=24, width=150)
    Label3.configure(background="white")
    Label3.configure(font=font10)
    Label3.configure(text='Degree')

    degree_entry = tkinter.Entry(education)
    degree_entry.place(relx=0.52, rely=0.18, height=24, relwidth=0.400)
    degree_entry.configure(background="light gray")
    degree_entry.configure(font=font9)
    degree_entry.configure(relief="flat")
    degree_entry.configure(justify="center")
    degree_entry.configure(foreground="#ffffff")

    ##################################
    Label4 = tkinter.Label(education)
    Label4.place(relx=0.02, rely=0.24, height=24, width=150)
    Label4.configure(background="white")
    Label4.configure(font=font10)
    Label4.configure(text='Field')

    field_entry = tkinter.Entry(education)
    field_entry.place(relx=0.52, rely=0.24, height=24, relwidth=0.400)
    field_entry.configure(background="light gray")
    field_entry.configure(font=font9)
    field_entry.configure(relief="flat")
    field_entry.configure(justify="center")
    field_entry.configure(foreground="#ffffff")

    ##################################
    Label5 = tkinter.Label(education)
    Label5.place(relx=0.02, rely=0.30, height=24, width=150)
    Label5.configure(background="white")
    Label5.configure(font=font10)
    Label5.configure(text='Start Year')

    start_entry = tkinter.Entry(education)
    start_entry.place(relx=0.52, rely=0.30, height=24, relwidth=0.400)
    start_entry.configure(background="light gray")
    start_entry.configure(font=font9)
    start_entry.configure(relief="flat")
    start_entry.configure(justify="center")
    start_entry.configure(foreground="#ffffff")

    ##################################
    Label6 = tkinter.Label(education)
    Label6.place(relx=0.02, rely=0.36, height=24, width=150)
    Label6.configure(background="white")
    Label6.configure(font=font10)
    Label6.configure(text='End Year')

    end_entry = tkinter.Entry(education)
    end_entry.place(relx=0.52, rely=0.36, height=24, relwidth=0.400)
    end_entry.configure(background="light gray")
    end_entry.configure(font=font9)
    end_entry.configure(relief="flat")
    end_entry.configure(justify="center")
    end_entry.configure(foreground="#ffffff")

    ##################################
    Label7 = tkinter.Label(education)
    Label7.place(relx=0.02, rely=0.42, height=24, width=150)
    Label7.configure(background="white")
    Label7.configure(font=font10)
    Label7.configure(text='Grade')

    grade_entry = tkinter.Entry(education)
    grade_entry.place(relx=0.52, rely=0.42, height=24, relwidth=0.400)
    grade_entry.configure(background="light gray")
    grade_entry.configure(font=font9)
    grade_entry.configure(relief="flat")
    grade_entry.configure(justify="center")
    grade_entry.configure(foreground="#ffffff")

    edit_button = tkinter.Button(education, command=lambda: add_education_db(school_entry.get(), degree_entry.get(), field_entry.get(), start_entry.get(), end_entry.get(), grade_entry.get()))
    edit_button.place(relx=0.13, rely=0.50, height=24, width=310)
    edit_button.configure(activebackground="#dfe6e9")
    edit_button.configure(background="#2d3436")
    edit_button.configure(font=font9)
    edit_button.configure(relief="flat")
    edit_button.configure(text='''Save Education''')
    edit_button.configure(foreground="#ffffff")

    return

def delete_education_ui():
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    education = tkinter.Frame(show_education_page)
    education.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    education.configure(relief='flat')
    education.configure(borderwidth="2")
    education.configure(background="light coral")
    education.configure(cursor="arrow")

    Label1 = tkinter.Label(show_education_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(education, command=delete_education_db)
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(education, command=show_education_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def show_experience_ui():
    global show_experience_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_experience_page = tkinter.Tk()
    show_experience_page.configure(background="#2d3436")
    show_experience_page.configure(cursor="arrow")
    show_experience_page.title('Experience Page')
    show_experience_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_experience_page, command=show_experience_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    experience = tkinter.Frame(show_experience_page)
    experience.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    experience.configure(relief='flat')
    experience.configure(borderwidth="2")
    experience.configure(background="#ffffff")
    experience.configure(cursor="arrow")

    Label1 = tkinter.Label(experience)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Experience Page")

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT Experience.experience_id, Experience.start_date, Experience.end_date , Experience.company, Experience.job_title FROM User, Experience WHERE Experience.user_email = User.email AND User.email = '{current_email}'")
    experiences = cursor.fetchall()
    ids = []
    companies = []
    jobs = []
    start = []
    end = []

    for index in range(len(experiences)):
        ids.append(experiences[index][0])
        companies.append(experiences[index][3])
        jobs.append(experiences[index][4])
        start.append(experiences[index][1])
        end.append(experiences[index][2])

    edit_button = tkinter.Button(experience, command=add_experience_ui)
    edit_button.place(relx=0.80, rely=0.02, height=24, width=150)
    edit_button.configure(activebackground="#dfe6e9")
    edit_button.configure(background="#2d3436")
    edit_button.configure(font=font9)
    edit_button.configure(relief="flat")
    edit_button.configure(text='''Add Experience''')
    edit_button.configure(foreground="#ffffff")


    rel_y = 0.25
    rel_y2 = 0.19
    if companies == []:
        Label1 = tkinter.Label(show_experience_page)
        Label1.place(relx=0.38, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        Label2 = tkinter.Label(show_experience_page)
        Label2.place(relx=0.23, rely=0.20, height=24, width=80)
        Label2.configure(background="light gray")
        Label2.configure(font=font10)
        Label2.configure(text="Company")

        Label3 = tkinter.Label(show_experience_page)
        Label3.place(relx=0.31, rely=0.20, height=24, width=80)
        Label3.configure(background="light gray")
        Label3.configure(font=font10)
        Label3.configure(text="Job Title")

        Label4 = tkinter.Label(show_experience_page)
        Label4.place(relx=0.39, rely=0.20, height=24, width=80)
        Label4.configure(background="light gray")
        Label4.configure(font=font10)
        Label4.configure(text="Start Year")

        Label5 = tkinter.Label(show_experience_page)
        Label5.place(relx=0.47, rely=0.20, height=24, width=80)
        Label5.configure(background="light gray")
        Label5.configure(font=font10)
        Label5.configure(text="End Year")

        global current_experience_id

        for index in range(len(companies)):
            current_experience_id = ids[index]
            Label6 = tkinter.Label(show_experience_page)
            Label6.place(relx=0.23, rely=rel_y, height=24, width=80)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=companies[index])

            Label7 = tkinter.Label(show_experience_page)
            Label7.place(relx=0.31, rely=rel_y, height=24, width=80)
            Label7.configure(background="white")
            Label7.configure(font=font10)
            Label7.configure(text=jobs[index])

            Label8 = tkinter.Label(show_experience_page)
            Label8.place(relx=0.39, rely=rel_y, height=24, width=80)
            Label8.configure(background="white")
            Label8.configure(font=font10)
            Label8.configure(text=start[index])

            Label9 = tkinter.Label(show_experience_page)
            Label9.place(relx=0.47, rely=rel_y, height=24, width=80)
            Label9.configure(background="white")
            Label9.configure(font=font10)
            Label9.configure(text=end[index])

            edit_button = tkinter.Button(experience, command= add_experience_ui)
            edit_button.place(relx=0.63, rely=rel_y2, height=24, width=120)
            edit_button.configure(activebackground="#dfe6e9")
            edit_button.configure(background="#2d3436")
            edit_button.configure(font=font9)
            edit_button.configure(relief="flat")
            edit_button.configure(text='''Edit Experience''')
            edit_button.configure(foreground="#ffffff")

            delete_button = tkinter.Button(experience, command=delete_experience_ui)
            delete_button.place(relx=0.80, rely=rel_y2, height=24, width=160)
            delete_button.configure(activebackground="#dfe6e9")
            delete_button.configure(background="#2d3436")
            delete_button.configure(font=font9)
            delete_button.configure(relief="flat")
            delete_button.configure(text='''Delete Experience''')
            delete_button.configure(foreground="#ffffff")

            rel_y += 0.05
            rel_y2 += 0.06
    return

def add_experience_ui():

    global experience_page
    global education
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    experience_page = tkinter.Tk()
    experience_page.configure(background="#2d3436")
    experience_page.configure(cursor="arrow")
    experience_page.title('Experience Page')
    experience_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(experience_page, command=experience_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    experience = tkinter.Frame(experience_page)
    experience.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    experience.configure(relief='flat')
    experience.configure(borderwidth="2")
    experience.configure(background="#ffffff")
    experience.configure(cursor="arrow")

    Label1 = tkinter.Label(experience)
    Label1.place(relx=0.28, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Add Experience')

    ##################################
    Label2 = tkinter.Label(experience)
    Label2.place(relx=0.02, rely=0.12, height=24, width=150)
    Label2.configure(background="white")
    Label2.configure(font=font10)
    Label2.configure(text='Company')

    compnay_entry = tkinter.Entry(experience)
    compnay_entry.place(relx=0.52, rely=0.12, height=24, relwidth=0.400)
    compnay_entry.configure(background="light gray")
    compnay_entry.configure(font=font9)
    compnay_entry.configure(relief="flat")
    compnay_entry.configure(justify="center")
    compnay_entry.configure(foreground="#ffffff")

    ##################################
    Label3 = tkinter.Label(experience)
    Label3.place(relx=0.02, rely=0.18, height=24, width=150)
    Label3.configure(background="white")
    Label3.configure(font=font10)
    Label3.configure(text='Job Title')

    job_entry = tkinter.Entry(experience)
    job_entry.place(relx=0.52, rely=0.18, height=24, relwidth=0.400)
    job_entry.configure(background="light gray")
    job_entry.configure(font=font9)
    job_entry.configure(relief="flat")
    job_entry.configure(justify="center")
    job_entry.configure(foreground="#ffffff")

    ##################################
    Label5 = tkinter.Label(experience)
    Label5.place(relx=0.02, rely=0.24, height=24, width=150)
    Label5.configure(background="white")
    Label5.configure(font=font10)
    Label5.configure(text='Start Year')

    start_entry = tkinter.Entry(experience)
    start_entry.place(relx=0.52, rely=0.24, height=24, relwidth=0.400)
    start_entry.configure(background="light gray")
    start_entry.configure(font=font9)
    start_entry.configure(relief="flat")
    start_entry.configure(justify="center")
    start_entry.configure(foreground="#ffffff")

    ##################################
    Label6 = tkinter.Label(experience)
    Label6.place(relx=0.02, rely=0.30, height=24, width=150)
    Label6.configure(background="white")
    Label6.configure(font=font10)
    Label6.configure(text='End Year')

    end_entry = tkinter.Entry(experience)
    end_entry.place(relx=0.52, rely=0.30, height=24, relwidth=0.400)
    end_entry.configure(background="light gray")
    end_entry.configure(font=font9)
    end_entry.configure(relief="flat")
    end_entry.configure(justify="center")
    end_entry.configure(foreground="#ffffff")

    edit_button = tkinter.Button(experience, command=lambda: add_experience_db(compnay_entry.get(), job_entry.get(), start_entry.get(), end_entry.get()))
    edit_button.place(relx=0.13, rely=0.40, height=24, width=310)
    edit_button.configure(activebackground="#dfe6e9")
    edit_button.configure(background="#2d3436")
    edit_button.configure(font=font9)
    edit_button.configure(relief="flat")
    edit_button.configure(text='''Save Experience''')
    edit_button.configure(foreground="#ffffff")

    return

def delete_experience_ui():
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    experience = tkinter.Frame(show_experience_page)
    experience.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    experience.configure(relief='flat')
    experience.configure(borderwidth="2")
    experience.configure(background="light coral")
    experience.configure(cursor="arrow")

    Label1 = tkinter.Label(show_experience_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(experience, command=delete_experience_db)
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(experience, command=show_experience_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def change_password_ui():
    email = current_email
    global change_password_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    change_password_page = tkinter.Tk()
    change_password_page.configure(background="#2d3436")
    change_password_page.configure(cursor="arrow")
    change_password_page.title('Change Password')
    change_password_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(change_password_page, command=change_password_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    password_edit = tkinter.Frame(change_password_page)
    password_edit.place(relx=0.05, rely=0.1, relheight=0.80, relwidth=0.90)
    password_edit.configure(relief='flat')
    password_edit.configure(borderwidth="2")
    password_edit.configure(background="#ffffff")
    password_edit.configure(cursor="arrow")

    Label1 = tkinter.Label(password_edit)
    Label1.place(relx=0.02, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text='Change Password')

    ##################################
    Label2 = tkinter.Label(password_edit)
    Label2.place(relx=0.0, rely=0.12, height=24, width=200)
    Label2.configure(background="white")
    Label2.configure(font=font10)
    Label2.configure(text='New Password')

    new_pass_entry = tkinter.Entry(password_edit)
    new_pass_entry.place(relx=0.15, rely=0.12, height=24, relwidth=0.100)
    new_pass_entry.configure(background="light gray")
    new_pass_entry.configure(font=font9)
    new_pass_entry.configure(relief="flat")
    new_pass_entry.configure(justify="center")
    new_pass_entry.configure(foreground="#ffffff")

    password_button = tkinter.Button(password_edit, command=lambda : change_password_db(new_pass_entry.get()))
    password_button.place(relx=0.025, rely=0.17, height=24, width=310)
    password_button.configure(activebackground="#dfe6e9")
    password_button.configure(background="#2d3436")
    password_button.configure(font=font9)
    password_button.configure(relief="flat")
    password_button.configure(text='''Save New Password''')
    password_button.configure(foreground="#ffffff")

def show_connection_ui():
    global connection_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    connection_page = tkinter.Tk()
    connection_page.configure(background="#2d3436")
    connection_page.configure(cursor="arrow")
    connection_page.title('Connections Page')
    connection_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(connection_page, command=connection_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    global connections

    connections = tkinter.Frame(connection_page)
    connections.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    connections.configure(relief='flat')
    connections.configure(borderwidth="2")
    connections.configure(background="#ffffff")
    connections.configure(cursor="arrow")

    Label1 = tkinter.Label(connections)
    Label1.place(relx=0.28, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Connections Page")

    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT DISTINCT email_to_me FROM Connections WHERE request = '{1}' AND accept = '{1}' AND email_me_to = '{current_email}'")
    connection_list = cursor.fetchall()
    cursor.execute(
        f"SELECT DISTINCT email_me_to FROM Connections WHERE request = '{1}' AND accept = '{1}' AND email_to_me = '{current_email}'")
    connection_list2 = cursor.fetchall()
    connection_list = connection_list2 + connection_list
    users = []

    for index in range(len(connection_list)):
        users.append(connection_list[index][0])

    recommend_button = tkinter.Button(connections, command=recommends_ui)
    recommend_button.place(relx=0.58, rely=0.93, height=28, width=150)
    recommend_button.configure(activebackground="#dfe6e9")
    recommend_button.configure(background="#2d3436")
    recommend_button.configure(font=font9)
    recommend_button.configure(relief="flat")
    recommend_button.configure(text='''Show Recommends''')
    recommend_button.configure(foreground="#ffffff")

    request_button = tkinter.Button(connections, command=requests_ui)
    request_button.place(relx=0.08, rely=0.93, height=28, width=150)
    request_button.configure(activebackground="#dfe6e9")
    request_button.configure(background="#2d3436")
    request_button.configure(font=font9)
    request_button.configure(relief="flat")
    request_button.configure(text='''Show Requests''')
    request_button.configure(foreground="#ffffff")

    rel_y = 0.24
    rel_y2 = 0.19
    if users == [] or users == None:
        Label1 = tkinter.Label(connection_page)
        Label1.place(relx=0.385, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
        Label1.after(2000, Label1.destroy)


    else:
        Label2 = tkinter.Label(connection_page)
        Label2.place(relx=0.40, rely=0.20, height=24, width=80)
        Label2.configure(background="light gray")
        Label2.configure(font=font10)
        Label2.configure(text="First Name")

        Label3 = tkinter.Label(connection_page)
        Label3.place(relx=0.5, rely=0.20, height=24, width=80)
        Label3.configure(background="light gray")
        Label3.configure(font=font10)
        Label3.configure(text="Last Name")

        first_names = []
        last_names = []
        for index in range(len(users)):
            cursor.execute(
                f"SELECT DISTINCT first_name, last_name FROM User WHERE email = '{users[index]}'")
            list = cursor.fetchone()
            if list != [] and list != None:
                first_names.append(list[0])
                last_names.append(list[1])


        for index in range(len(users)):
            if first_names[index] == None or first_names[index] == '':
                first_names[index] = 'First Name' + str(index+1)
            if last_names[index] == None or last_names[index] == '':
                last_names[index] = 'Last Name' + str(index+1)

            Label2 = tkinter.Label(connection_page)
            Label2.place(relx=0.36, rely=rel_y, height=24, width=30)
            Label2.configure(background="gray")
            Label2.configure(font=font10)
            Label2.configure(text=index + 1)

            Label6 = tkinter.Label(connection_page)
            Label6.place(relx=0.3955, rely=rel_y, height=24, width=90)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=first_names[index])

            Label7 = tkinter.Label(connection_page)
            Label7.place(relx=0.5, rely=rel_y, height=24, width=90)
            Label7.configure(background="white")
            Label7.configure(font=font10)
            Label7.configure(text=last_names[index])

            rel_y += 0.05
            rel_y2 += 0.06

        Label2 = tkinter.Label(connections)
        Label2.place(relx=0.0, rely=0.85, height=24, width=270)
        Label2.configure(background="white")
        Label2.configure(font=font9)
        Label2.configure(text='Which Number Do You Want to Delete?')

        choice_entry = tkinter.Entry(connections)
        choice_entry.place(relx=0.64, rely=0.85, height=24, relwidth=0.04)
        choice_entry.configure(background="light gray")
        choice_entry.configure(font=font9)
        choice_entry.configure(relief="flat")
        choice_entry.configure(justify="center")
        choice_entry.configure(foreground="#ffffff")

        delete_button = tkinter.Button(connections, command=lambda: delete_network_db(choice_entry.get(), users))
        delete_button.place(relx=0.69, rely=0.85, height=24, width=120)
        delete_button.configure(activebackground="#dfe6e9")
        delete_button.configure(background="#2d3436")
        delete_button.configure(font=font9)
        delete_button.configure(relief="flat")
        delete_button.configure(text='''Delete Connection''')
        delete_button.configure(foreground="#ffffff")

    return

def requests_ui():
    global request_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    request_page = tkinter.Tk()
    request_page.configure(background="#2d3436")
    request_page.configure(cursor="arrow")
    request_page.title('Connections Page')
    request_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(request_page, command=request_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    request = tkinter.Frame(request_page)
    request.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    request.configure(relief='flat')
    request.configure(borderwidth="2")
    request.configure(background="#ffffff")
    request.configure(cursor="arrow")

    Label1 = tkinter.Label(request)
    Label1.place(relx=0.28, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Requests")

    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT email_me_to FROM Connections WHERE email_to_me = '{current_email}' AND request = '{1}' AND accept = '{0}';")
    my_request_list = cursor.fetchall()
    users = []
    if my_request_list == [] or my_request_list == None:
        Label1 = tkinter.Label(request_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''Empty List''')
        Label1.after(2000, Label1.destroy)
    else:
        for index in range(len(my_request_list)):
            users.append(my_request_list[index][0])

    first_name = []
    last_name = []
    if users != []:
        for user in users:
            cursor.execute(
                f"SELECT DISTINCT User.first_name, User.last_name FROM User WHERE email = '{user}'")
            name = cursor.fetchone()
            if name != [] or name != None:
                first_name.append(name[0])
                last_name.append(name[1])

        rel_y = 0.15
        global current_connection_id
        for index in range(len(users)):
            email = users[index]
            Label6 = tkinter.Label(request)
            Label6.place(relx=0.03, rely=rel_y, height=24, width=120)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=first_name[index] + ' ' + last_name[index])

            accept_button = tkinter.Button(request, command=lambda: accept_request_ui(email))
            accept_button.place(relx=0.43, rely=rel_y, height=24, width=100)
            accept_button.configure(activebackground="#dfe6e9")
            accept_button.configure(background="#2d3436")
            accept_button.configure(font=font9)
            accept_button.configure(relief="flat")
            accept_button.configure(text='''Accept''')
            accept_button.configure(foreground="#ffffff")

            decline_button = tkinter.Button(request, command=lambda: decline_request_ui(email))
            decline_button.place(relx=0.73, rely=rel_y, height=24, width=100)
            decline_button.configure(activebackground="#dfe6e9")
            decline_button.configure(background="#2d3436")
            decline_button.configure(font=font9)
            decline_button.configure(relief="flat")
            decline_button.configure(text='''Decline''')
            decline_button.configure(foreground="#ffffff")

            rel_y += 0.05

    connection.close()
    return

def add_connection_ui(email):
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT connection_id FROM Connections")
    result = cursor.fetchall()
    connection_id = len(result)
    cursor.execute(f"INSERT INTO Connections (connection_id, email_me_to, email_to_me, request , accept) VALUES ('{connection_id}', '{current_email}', '{email}', '{1}', '{0}')")
    connection.commit()

    Label1 = tkinter.Label(profile_page)
    Label1.place(relx=0.385, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font10)
    Label1.configure(text='You requested to "' + str(email) + '"')
    Label1.after(2000, Label1.destroy)

    return

def accept_request_ui(email):
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"UPDATE Connections SET accept = '{1}' WHERE email_to_me = '{current_email}' AND email_me_to = '{email}'")
    connection.commit()

    Label1 = tkinter.Label(request_page)
    Label1.place(relx=0.385, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font10)
    Label1.configure(text='You accepted ' + str(email) + "'s request.")
    Label1.after(2000, Label1.destroy)

    return

def decline_request_ui(email):
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"DELETE FROM Connections WHERE email_to_me = '{current_email}' AND email_me_to = '{email}'")
    connection.commit()

    Label1 = tkinter.Label(request_page)
    Label1.place(relx=0.385, rely=0.10, height=24, width=315)
    Label1.configure(background="pale green")
    Label1.configure(font=font10)
    Label1.configure(text='You declined ' + str(email) + "'s request.")
    Label1.after(2000, Label1.destroy)

    return

def delete_connection_ui(email_index, list):
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    skill = tkinter.Frame(connection_page)
    skill.place(relx=0.394, rely=0.31, relheight=0.20, relwidth=0.17)
    skill.configure(relief='flat')
    skill.configure(borderwidth="2")
    skill.configure(background="light coral")
    skill.configure(cursor="arrow")

    Label1 = tkinter.Label(connection_page)
    Label1.place(relx=0.415, rely=0.35, height=24, width=200)
    Label1.configure(background="light coral")
    Label1.configure(font=font10)
    Label1.configure(text='''Are You Sure ?''')

    yes_button = tkinter.Button(connections, command=lambda:delete_network_db(email_index, list))
    yes_button.place(relx=0.125, rely=0.80, height=24, width=80)
    yes_button.configure(activebackground="#dfe6e9")
    yes_button.configure(background="red")
    yes_button.configure(font=font9)
    yes_button.configure(relief="flat")
    yes_button.configure(text='''Yes''')
    yes_button.configure(foreground="#ffffff")

    cancel_button = tkinter.Button(skill, command=show_connection_ui)
    cancel_button.place(relx=0.555, rely=0.80, height=24, width=80)
    cancel_button.configure(activebackground="#dfe6e9")
    cancel_button.configure(background="pale green")
    cancel_button.configure(font=font9)
    cancel_button.configure(relief="flat")
    cancel_button.configure(text='''Cancel''')
    cancel_button.configure(foreground="#ffffff")

    return

def recommends_ui():
    global recommends_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    recommends_page = tkinter.Tk()
    recommends_page.configure(background="#2d3436")
    recommends_page.configure(cursor="arrow")
    recommends_page.title('Connections Page')
    recommends_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(recommends_page, command=recommends_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    global recommend

    recommend = tkinter.Frame(recommends_page)
    recommend.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    recommend.configure(relief='flat')
    recommend.configure(borderwidth="2")
    recommend.configure(background="#ffffff")
    recommend.configure(cursor="arrow")

    Label1 = tkinter.Label(recommend)
    Label1.place(relx=0.28, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Recommends")

    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT DISTINCT email_to_me FROM Connections WHERE email_me_to = '{current_email}'")
    my_network_list = cursor.fetchall()
    users = []
    for index in range(len(my_network_list)):
        users.append(my_network_list[index][0])

    first_name = []
    last_name = []
    my_networks_network_list = []
    if users != []:
        for user in users:
            cursor.execute(f"SELECT DISTINCT email_to_me FROM Connections WHERE email_me_to = '{user}'")
            user2 = cursor.fetchone()
            if user2 != current_email:
                my_networks_network_list.append(user2)

        for user in my_networks_network_list:
            cursor.execute(f"SELECT DISTINCT User.first_name, User.last_name FROM User, Connections WHERE email = email_me_to AND email_me_to = '{user}'")
            name = cursor.fetchone()
            if name != None or name != []:
                first_name.append(name[0])
                last_name.append(name[1])

        rel_y = 0.25
        rel_y2 = 0.19
        global current_connection_id
        for index in range(len(my_networks_network_list)):
            current_connection_id = my_networks_network_list[index]
            Label6 = tkinter.Label(recommends_page)
            Label6.place(relx=0.23, rely=rel_y, height=24, width=120)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=first_name[index] + ' ' + last_name[index])

            network_button = tkinter.Button(recommend, command=lambda: add_connection_ui(my_networks_network_list[index]))
            network_button.place(relx=0.63, rely=rel_y2, height=24, width=100)
            network_button.configure(activebackground="#dfe6e9")
            network_button.configure(background="#2d3436")
            network_button.configure(font=font9)
            network_button.configure(relief="flat")
            network_button.configure(text='''Make Network''')
            network_button.configure(foreground="#ffffff")

            rel_y += 0.05
            rel_y2 += 0.06
    else:
        cursor.execute(f"SELECT DISTINCT email, first_name, last_name FROM User")
        list = cursor.fetchall()
        users = []
        for index in range(len(list)):
            if list[index][0] != current_email:
                users.append(list[index][0])
                first_name.append(list[index][1])
                last_name.append(list[index][2])
        rel_y = 0.25
        rel_y2 = 0.19
        global current_random_connection_id
        for index in range(3):
            if (first_name[index] != None and first_name[index] != '') and (last_name[index] != None and last_name[index] != ''):
                current_random_connection_id = users[index]
                Label6 = tkinter.Label(recommends_page)
                Label6.place(relx=0.23, rely=rel_y, height=24, width=80)
                Label6.configure(background="white")
                Label6.configure(font=font10)
                Label6.configure(text=first_name[index] + ' ' + last_name[index])
            else:
                current_random_connection_id = users[index]
                Label6 = tkinter.Label(recommends_page)
                Label6.place(relx=0.40, rely=rel_y, height=24, width=80)
                Label6.configure(background="white")
                Label6.configure(font=font10)
                Label6.configure(text='User'+str(index+1))

            network_button = tkinter.Button(recommend, command=lambda: make_network_db(current_random_connection_id))
            network_button.place(relx=0.63, rely=rel_y2, height=24, width=100)
            network_button.configure(activebackground="#dfe6e9")
            network_button.configure(background="#2d3436")
            network_button.configure(font=font9)
            network_button.configure(relief="flat")
            network_button.configure(text='''Make Network''')
            network_button.configure(foreground="#ffffff")

            rel_y += 0.05
            rel_y2 += 0.06

    return

def print_profile_search_result_ui(result):
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    rel_y = 0.35
    if result == [] or result == None:
        font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
        Label1 = tkinter.Label(user_search_page)
        Label1.place(relx=0.43, rely=0.21, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font9)
        Label1.configure(text='''No Results Found.''')
        Label1.after(2000, Label1.destroy)
        connection.close()
    else:
        for index in range(len(result)):
            Label2 = tkinter.Label(Frame55)
            Label2.place(relx=0.10, rely=rel_y, height=24, width=30)
            Label2.configure(background="gray")
            Label2.configure(font=font10)
            Label2.configure(text=index + 1)

            Label3 = tkinter.Label(Frame55)
            Label3.place(relx=0.15, rely=rel_y, height=24, width=300)
            Label3.configure(background="white")
            Label3.configure(font=font10)
            Label3.configure(text=result[index])

            rel_y += 0.05

        Label4 = tkinter.Label(Frame55)
        Label4.place(relx=0.15, rely=0.93, height=24, width=280)
        Label4.configure(background="white")
        Label4.configure(font=font10)
        Label4.configure(text='Which Number Do You Want to See?')

        choice_entry = tkinter.Entry(Frame55)
        choice_entry.place(relx=0.61, rely=0.93, height=24, relwidth=0.04)
        choice_entry.configure(background="light gray")
        choice_entry.configure(font=font9)
        choice_entry.configure(relief="flat")
        choice_entry.configure(justify="center")
        choice_entry.configure(foreground="#ffffff")

        add_button = tkinter.Button(Frame55, command=lambda: show_profile_ui(result[index]))
        add_button.place(relx=0.67, rely=0.93, height=24, width=90)
        add_button.configure(activebackground="#dfe6e9")
        add_button.configure(background="#2d3436")
        add_button.configure(font=font9)
        add_button.configure(relief="flat")
        add_button.configure(text='''Show Profile''')
        add_button.configure(foreground="#ffffff")

    return

def show_profile_ui(email):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT first_name, last_name, phone_number, gender, birthday, location_country, location_city, date_joined, last_update, language, summery FROM User WHERE email = '{email}'")
    name = cursor.fetchone()
    first_name = name[0]
    last_name = name[1]
    phone_number = name[2]
    gender = name[3]
    birthday = name[4]
    country = name[5]
    city = name[6]
    language = name[9]
    date_joined = name[7]
    last_update = name[8]
    summery = name[10]

    cursor.execute(
        f"SELECT post FROM Featured WHERE user_email = '{email}'")
    features = cursor.fetchall()
    cursor.execute(
        f"SELECT accomplishment FROM Accomplishments WHERE user_email = '{email}'")
    accomp = cursor.fetchall()
    if (last_name != None or last_name != '' or last_name != 'None') and (
            first_name != None or first_name != '' or first_name != 'None'):
        name = str(first_name) + ' ' + str(last_name)
    else:
        name = 'Welcome.'

    cursor.execute(f"SELECT SkillsList.title FROM User, SkillsList, UserSkills WHERE User.email = UserSkills.email_user AND UserSkills.skill_id = SkillsList.skill_id")
    skills = cursor.fetchall()

    global profile_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    profile_page = tkinter.Tk()
    profile_page.configure(background="#2d3436")
    profile_page.configure(cursor="arrow")
    profile_page.title('Profile Page')
    profile_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(profile_page, command=profile_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    global notif_list
    notif_list.append(['visit', current_email, None, email])

    global Profile
    Profile = tkinter.Frame(profile_page)
    Profile.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    Profile.configure(relief='flat')
    Profile.configure(borderwidth="2")
    Profile.configure(background="#ffffff")
    Profile.configure(cursor="arrow")

    Label1 = tkinter.Label(Profile)
    Label1.place(relx=0.28, rely=0.02, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text=name)

    Label2 = tkinter.Label(Profile)
    Label2.place(relx=0.02, rely=0.07, height=24, width=100)
    Label2.configure(background="light gray")
    Label2.configure(font=font10)
    Label2.configure(text='''Email Address''')

    Label21 = tkinter.Label(Profile)
    Label21.place(relx=0.37, rely=0.07, height=24, width=250)
    Label21.configure(background="white")
    Label21.configure(font=font10)
    Label21.configure(text=current_email)

    Label3 = tkinter.Label(Profile)
    Label3.place(relx=0.02, rely=0.11, height=24, width=100)
    Label3.configure(background="light gray")
    Label3.configure(font=font10)
    Label3.configure(text='''Phone Number''')

    Label31 = tkinter.Label(Profile)
    Label31.place(relx=0.37, rely=0.11, height=24, width=250)
    Label31.configure(background="white")
    Label31.configure(font=font10)
    Label31.configure(text=phone_number)

    Label4 = tkinter.Label(Profile)
    Label4.place(relx=0.02, rely=0.15, height=24, width=100)
    Label4.configure(background="light gray")
    Label4.configure(font=font10)
    Label4.configure(text='''Gender''')

    if gender == 'F':
        Label41 = tkinter.Label(Profile)
        Label41.place(relx=0.37, rely=0.15, height=24, width=250)
        Label41.configure(background="white")
        Label41.configure(font=font10)
        Label41.configure(text='''Female''')

    if gender == 'M':
        Label41 = tkinter.Label(Profile)
        Label41.place(relx=0.37, rely=0.15, height=24, width=250)
        Label41.configure(background="white")
        Label41.configure(font=font10)
        Label41.configure(text='''Male''')
    if gender != 'M' and gender != 'F':
        Label41 = tkinter.Label(Profile)
        Label41.place(relx=0.37, rely=0.15, height=24, width=250)
        Label41.configure(background="white")
        Label41.configure(font=font10)
        Label41.configure(text='''None''')

    Label5 = tkinter.Label(Profile)
    Label5.place(relx=0.02, rely=0.19, height=24, width=100)
    Label5.configure(background="light gray")
    Label5.configure(font=font10)
    Label5.configure(text='''Birthday''')

    if birthday == '' or birthday == None: birthday = 'None'
    Label51 = tkinter.Label(Profile)
    Label51.place(relx=0.37, rely=0.19, height=24, width=250)
    Label51.configure(background="white")
    Label51.configure(font=font10)
    Label51.configure(text=birthday)

    Label6 = tkinter.Label(Profile)
    Label6.place(relx=0.02, rely=0.23, height=24, width=100)
    Label6.configure(background="light gray")
    Label6.configure(font=font10)
    Label6.configure(text='''Location''')

    if (country == '' or country == None) or (city == '' or city == None): country = city = 'None'
    Label61 = tkinter.Label(Profile)
    Label61.place(relx=0.37, rely=0.23, height=24, width=250)
    Label61.configure(background="white")
    Label61.configure(font=font10)
    Label61.configure(text=str(country) + ' ' + str(city))

    Label9 = tkinter.Label(Profile)
    Label9.place(relx=0.02, rely=0.27, height=24, width=100)
    Label9.configure(background="light gray")
    Label9.configure(font=font10)
    Label9.configure(text='''Language''')

    if language == '' or language == None:
        language = 'None'
    elif language == 'Per':
        language = 'Persian'
    elif language == 'En':
        language = 'English'
    Label91 = tkinter.Label(Profile)
    Label91.place(relx=0.37, rely=0.27, height=24, width=250)
    Label91.configure(background="white")
    Label91.configure(font=font10)
    Label91.configure(text=str(language))

    Label7 = tkinter.Label(Profile)
    Label7.place(relx=0.02, rely=0.31, height=24, width=100)
    Label7.configure(background="light gray")
    Label7.configure(font=font10)
    Label7.configure(text='''Date Joined''')

    Label71 = tkinter.Label(Profile)
    Label71.place(relx=0.37, rely=0.31, height=24, width=250)
    Label71.configure(background="white")
    Label71.configure(font=font10)
    Label71.configure(text=date_joined)

    Label8 = tkinter.Label(Profile)
    Label8.place(relx=0.02, rely=0.35, height=24, width=100)
    Label8.configure(background="light gray")
    Label8.configure(font=font10)
    Label8.configure(text='''Last Update''')

    Label81 = tkinter.Label(Profile)
    Label81.place(relx=0.37, rely=0.35, height=24, width=250)
    Label81.configure(background="white")
    Label81.configure(font=font10)
    Label81.configure(text=last_update)
    ###########################################################

    Label99 = tkinter.Label(Profile)
    Label99.place(relx=0.02, rely=0.39, height=24, width=80)
    Label99.configure(background="white")
    Label99.configure(font=font10)
    Label99.configure(text='''Summery:''')

    Label991 = tkinter.Label(Profile)
    Label991.place(relx=0.28, rely=0.39, height=54, width=280)
    Label991.configure(background="light gray")
    Label991.configure(font=font10)
    Label991.configure(text=summery)

    Label992 = tkinter.Label(Profile)
    Label992.place(relx=0.02, rely=0.48, height=24, width=80)
    Label992.configure(background="white")
    Label992.configure(font=font10)
    Label992.configure(text='''Featured:''')

    Label9922 = tkinter.Label(Profile)
    Label9922.place(relx=0.28, rely=0.48, height=54, width=280)
    Label9922.configure(background="light gray")
    Label9922.configure(font=font10)
    Label9922.configure(text=features)

    Label993 = tkinter.Label(Profile)
    Label993.place(relx=0.01, rely=0.57, height=24, width=100)
    Label993.configure(background="white")
    Label993.configure(font=font10)
    Label993.configure(text='''Accomplished:''')

    Label993 = tkinter.Label(Profile)
    Label993.place(relx=0.28, rely=0.57, height=54, width=280)
    Label993.configure(background="light gray")
    Label993.configure(font=font10)
    Label993.configure(text=accomp)


    ###########################################################
    show_skill_button = tkinter.Button(Profile, command=lambda: show_other_skills_ui(email))
    show_skill_button.place(relx=0.32, rely=0.68, height=24, width=150)
    show_skill_button.configure(activebackground="#dfe6e9")
    show_skill_button.configure(background="#2d3436")
    show_skill_button.configure(font=font9)
    show_skill_button.configure(relief="flat")
    show_skill_button.configure(text='''Show Skills''')
    show_skill_button.configure(foreground="#ffffff")

    show_education_button = tkinter.Button(Profile, command=lambda: show_other_education_ui(email))
    show_education_button.place(relx=0.32, rely=0.74, height=24, width=150)
    show_education_button.configure(activebackground="#dfe6e9")
    show_education_button.configure(background="#2d3436")
    show_education_button.configure(font=font9)
    show_education_button.configure(relief="flat")
    show_education_button.configure(text='''Show Educations''')
    show_education_button.configure(foreground="#ffffff")

    show_experience_button = tkinter.Button(Profile, command=lambda: show_other_experience_ui(email))
    show_experience_button.place(relx=0.32, rely=0.8, height=24, width=150)
    show_experience_button.configure(activebackground="#dfe6e9")
    show_experience_button.configure(background="#2d3436")
    show_experience_button.configure(font=font9)
    show_experience_button.configure(relief="flat")
    show_experience_button.configure(text='''Show Experiences''')
    show_experience_button.configure(foreground="#ffffff")

    show_connections_button = tkinter.Button(Profile, command=lambda: show_other_connection_ui(email))
    show_connections_button.place(relx=0.32, rely=0.86, height=24, width=150)
    show_connections_button.configure(activebackground="#dfe6e9")
    show_connections_button.configure(background="#2d3436")
    show_connections_button.configure(font=font9)
    show_connections_button.configure(relief="flat")
    show_connections_button.configure(text='''Show Connections''')
    show_connections_button.configure(foreground="#ffffff")

    cursor.execute(f"SELECT DISTINCT email_to_me FROM Connections WHERE request = '{1}' AND accept = '{1}' AND (email_me_to = '{current_email}' OR email_to_me = '{current_email}')")
    result = cursor.fetchall()
    r = []
    for index in range(len(result)): r.append(result[index][0])
    if email not in r:
        request_button = tkinter.Button(Profile, command=lambda: add_connection_ui(email))
        request_button.place(relx=0.32, rely=0.92, height=24, width=150)
        request_button.configure(activebackground="#dfe6e9")
        request_button.configure(background="#2d3436")
        request_button.configure(font=font9)
        request_button.configure(relief="flat")
        request_button.configure(text='''Make Network''')
        request_button.configure(foreground="#ffffff")

    return

def show_other_skills_ui(email):
    global show_other_skill_page
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_other_skill_page = tkinter.Tk()
    show_other_skill_page.configure(background="#2d3436")
    show_other_skill_page.configure(cursor="arrow")
    show_other_skill_page.title('Skill Page')
    show_other_skill_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_other_skill_page, command=show_other_skill_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    other_skill = tkinter.Frame(show_other_skill_page)
    other_skill.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    other_skill.configure(relief='flat')
    other_skill.configure(borderwidth="2")
    other_skill.configure(background="#ffffff")
    other_skill.configure(cursor="arrow")

    Label1 = tkinter.Label(other_skill)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Skills Page")

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT DISTINCT SkillsList.skill_id, SkillsList.title FROM User, UserSkills, SkillsList WHERE SkillsList.skill_id = UserSkills.skill_id AND UserSkills.email_user = User.email AND User.email = '{email}'")
    result = cursor.fetchall()
    ids = []
    titles = []

    for index in range(len(result)):
        ids.append(result[index][0])
        titles.append(result[index][1])

    rel_y = 0.09
    endorsers = []
    if titles == []:
        Label1 = tkinter.Label(show_other_skill_page)
        Label1.place(relx=0.394, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        for index in range(len(titles)):
            cursor.execute(f"SELECT DISTINCT User.first_name, User.last_name FROM Endorsements, User WHERE Endorsements.skill_id = '{ids[index - 1]}'")
            list = cursor.fetchall()
            for item in list:
                endorsers.append(item[0] + ' ' + item[1])

            Label2 = tkinter.Label(other_skill)
            Label2.place(relx=0.07, rely=rel_y, height=24, width=30)
            Label2.configure(background="gray")
            Label2.configure(font=font10)
            Label2.configure(text=index + 1)

            Label3 = tkinter.Label(other_skill)
            Label3.place(relx=0.10, rely=rel_y, height=24, width=300)
            Label3.configure(background="white")
            Label3.configure(font=font10)
            Label3.configure(text=titles[index])

            if len(endorsers) > 5:
                Label4 = tkinter.Label(other_skill)
                Label4.place(relx=0.12, rely=rel_y + 0.05, height=35, width=470)
                Label4.configure(background="white")
                Label4.configure(font=font10)
                Label4.configure(text=str(endorsers[:5]))
            if len(endorsers) < 5:
                Label4 = tkinter.Label(other_skill)
                Label4.place(relx=0.12, rely=rel_y + 0.05, height=3, width=470)
                Label4.configure(background="white")
                Label4.configure(font=font10)
                Label4.configure(text=str(endorsers))
            if endorsers == []:
                Label4 = tkinter.Label(other_skill)
                Label4.place(relx=0.12, rely=rel_y + 0.05, height=35, width=470)
                Label4.configure(background="light gray")
                Label4.configure(font=font10)
                Label4.configure(text="Nobody Endorse this Skill.")

            rel_y += 0.15

    return

def show_other_education_ui(email):
    global show_education

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_education = tkinter.Tk()
    show_education.configure(background="#2d3436")
    show_education.configure(cursor="arrow")
    show_education.title('Education Page')
    show_education.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_education, command=show_education.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    education = tkinter.Frame(show_education)
    education.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    education.configure(relief='flat')
    education.configure(borderwidth="2")
    education.configure(background="#ffffff")
    education.configure(cursor="arrow")

    Label1 = tkinter.Label(education)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Educations Page")

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT DISTINCT Education.education_id, Education.school, Education.degree, Education.start_year, Education.end_year FROM User, Education WHERE Education.user_email = User.email AND User.email = '{email}'")
    educations = cursor.fetchall()
    ids = []
    schools = []
    degrees = []
    start = []
    end = []
    for index in range(len(educations)):
        ids.append(educations[index][0])
        schools.append(educations[index][1])
        degrees.append(educations[index][2])
        start.append(educations[index][3])
        end.append(educations[index][4])

    rel_y = 0.25
    if schools == [] and degrees == []:
        Label1 = tkinter.Label(show_education)
        Label1.place(relx=0.38, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        Label2 = tkinter.Label(show_education)
        Label2.place(relx=0.23, rely=0.20, height=24, width=80)
        Label2.configure(background="light gray")
        Label2.configure(font=font10)
        Label2.configure(text="School")

        Label3 = tkinter.Label(show_education)
        Label3.place(relx=0.31, rely=0.20, height=24, width=80)
        Label3.configure(background="light gray")
        Label3.configure(font=font10)
        Label3.configure(text="Degree")

        Label4 = tkinter.Label(show_education)
        Label4.place(relx=0.39, rely=0.20, height=24, width=80)
        Label4.configure(background="light gray")
        Label4.configure(font=font10)
        Label4.configure(text="Start Year")

        Label5 = tkinter.Label(show_education)
        Label5.place(relx=0.47, rely=0.20, height=24, width=80)
        Label5.configure(background="light gray")
        Label5.configure(font=font10)
        Label5.configure(text="End Year")

        global current_education_id

        for index in range(len(schools)):
            current_education_id = ids[index]
            Label6 = tkinter.Label(show_education_page)
            Label6.place(relx=0.23, rely=rel_y, height=24, width=80)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=schools[index])

            Label7 = tkinter.Label(show_education_page)
            Label7.place(relx=0.31, rely=rel_y, height=24, width=80)
            Label7.configure(background="white")
            Label7.configure(font=font10)
            Label7.configure(text=degrees[index])

            Label8 = tkinter.Label(show_education_page)
            Label8.place(relx=0.39, rely=rel_y, height=24, width=80)
            Label8.configure(background="white")
            Label8.configure(font=font10)
            Label8.configure(text=start[index])

            Label9 = tkinter.Label(show_education_page)
            Label9.place(relx=0.47, rely=rel_y, height=24, width=80)
            Label9.configure(background="white")
            Label9.configure(font=font10)
            Label9.configure(text=end[index])

            rel_y += 0.05
    return

def show_other_experience_ui(email):
    global show_experience

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    show_experience = tkinter.Tk()
    show_experience.configure(background="#2d3436")
    show_experience.configure(cursor="arrow")
    show_experience.title('Experience Page')
    show_experience.attributes('-fullscreen', True)

    back_button = tkinter.Button(show_experience, command=show_experience.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    experience = tkinter.Frame(show_experience)
    experience.place(relx=0.201, rely=0.092, relheight=0.807, relwidth=0.571)
    experience.configure(relief='flat')
    experience.configure(borderwidth="2")
    experience.configure(background="#ffffff")
    experience.configure(cursor="arrow")

    Label1 = tkinter.Label(experience)
    Label1.place(relx=0.4, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Experience Page")

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT DISTINCT Experience.experience_id, Experience.start_date, Experience.end_date , Experience.company, Experience.job_title FROM User, Experience WHERE Experience.user_email = User.email AND User.email = '{email}'")
    experiences = cursor.fetchall()
    ids = []
    companies = []
    jobs = []
    start = []
    end = []

    for index in range(len(experiences)):
        ids.append(experiences[index][0])
        companies.append(experiences[index][3])
        jobs.append(experiences[index][4])
        start.append(experiences[index][1])
        end.append(experiences[index][2])

    rel_y = 0.25
    if companies == []:
        Label1 = tkinter.Label(show_experience)
        Label1.place(relx=0.38, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')
    else:
        Label2 = tkinter.Label(show_experience)
        Label2.place(relx=0.23, rely=0.20, height=24, width=80)
        Label2.configure(background="light gray")
        Label2.configure(font=font10)
        Label2.configure(text="Company")

        Label3 = tkinter.Label(show_experience)
        Label3.place(relx=0.31, rely=0.20, height=24, width=80)
        Label3.configure(background="light gray")
        Label3.configure(font=font10)
        Label3.configure(text="Job Title")

        Label4 = tkinter.Label(show_experience)
        Label4.place(relx=0.39, rely=0.20, height=24, width=80)
        Label4.configure(background="light gray")
        Label4.configure(font=font10)
        Label4.configure(text="Start Year")

        Label5 = tkinter.Label(show_experience)
        Label5.place(relx=0.47, rely=0.20, height=24, width=80)
        Label5.configure(background="light gray")
        Label5.configure(font=font10)
        Label5.configure(text="End Year")

        global current_experience_id

        for index in range(len(companies)):
            current_experience_id = ids[index]
            Label6 = tkinter.Label(show_experience)
            Label6.place(relx=0.23, rely=rel_y, height=24, width=80)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=companies[index])

            Label7 = tkinter.Label(show_experience)
            Label7.place(relx=0.31, rely=rel_y, height=24, width=80)
            Label7.configure(background="white")
            Label7.configure(font=font10)
            Label7.configure(text=jobs[index])

            Label8 = tkinter.Label(show_experience)
            Label8.place(relx=0.39, rely=rel_y, height=24, width=80)
            Label8.configure(background="white")
            Label8.configure(font=font10)
            Label8.configure(text=start[index])

            Label9 = tkinter.Label(show_experience)
            Label9.place(relx=0.47, rely=rel_y, height=24, width=80)
            Label9.configure(background="white")
            Label9.configure(font=font10)
            Label9.configure(text=end[index])

            rel_y += 0.05
    return

def show_other_connection_ui(email):
    global connection_page_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    connection_page_page = tkinter.Tk()
    connection_page_page.configure(background="#2d3436")
    connection_page_page.configure(cursor="arrow")
    connection_page_page.title('Connections Page')
    connection_page_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(connection_page_page, command=connection_page_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    global connections

    connections = tkinter.Frame(connection_page_page)
    connections.place(relx=0.351, rely=0.092, relheight=0.807, relwidth=0.271)
    connections.configure(relief='flat')
    connections.configure(borderwidth="2")
    connections.configure(background="#ffffff")
    connections.configure(cursor="arrow")

    Label1 = tkinter.Label(connections)
    Label1.place(relx=0.28, rely=0.05, height=24, width=200)
    Label1.configure(background="light gray")
    Label1.configure(font=font10)
    Label1.configure(text="Connections Page")

    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT DISTINCT email_to_me FROM Connections WHERE email_me_to = '{email}'")
    connection_list = cursor.fetchall()
    users = []

    for index in range(len(connection_list)):
        users.append(connection_list[index][0])

    rel_y = 0.24
    if users == []:
        Label1 = tkinter.Label(connection_page_page)
        Label1.place(relx=0.385, rely=0.10, height=24, width=315)
        Label1.configure(background="light coral")
        Label1.configure(font=font10)
        Label1.configure(text='Empty List')

    else:
        Label2 = tkinter.Label(connection_page_page)
        Label2.place(relx=0.40, rely=0.20, height=24, width=80)
        Label2.configure(background="light gray")
        Label2.configure(font=font10)
        Label2.configure(text="First Name")

        Label3 = tkinter.Label(connection_page_page)
        Label3.place(relx=0.5, rely=0.20, height=24, width=80)
        Label3.configure(background="light gray")
        Label3.configure(font=font10)
        Label3.configure(text="Last Name")

        first_names = []
        last_names = []
        for index in range(len(users)):
            cursor.execute(
                f"SELECT DISTINCT first_name, last_name FROM User WHERE email = '{users[index]}'")
            list = cursor.fetchone()
            first_names.append(list[0])
            last_names.append(list[0])

        for index in range(len(users)):
            if first_names[index] == None or first_names[index] == '':
                first_names[index] = 'First Name' + str(index + 1)
            if last_names[index] == None or last_names[index] == '':
                last_names[index] = 'Last Name' + str(index + 1)

            Label2 = tkinter.Label(connection_page_page)
            Label2.place(relx=0.36, rely=rel_y, height=24, width=30)
            Label2.configure(background="gray")
            Label2.configure(font=font10)
            Label2.configure(text=index + 1)

            Label6 = tkinter.Label(connection_page_page)
            Label6.place(relx=0.3955, rely=rel_y, height=24, width=90)
            Label6.configure(background="white")
            Label6.configure(font=font10)
            Label6.configure(text=first_names[index])

            Label7 = tkinter.Label(connection_page_page)
            Label7.place(relx=0.5, rely=rel_y, height=24, width=90)
            Label7.configure(background="white")
            Label7.configure(font=font10)
            Label7.configure(text=last_names[index])

            rel_y += 0.05

    return

def user_search_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global user_search_page

    user_search_page = tkinter.Tk()
    user_search_page.title('Search an user')
    user_search_page.attributes('-fullscreen', True)
    user_search_page.configure(background="#2d3436")

    global Frame55
    Frame55 = tkinter.Frame(user_search_page)
    Frame55.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.371)
    Frame55.configure(borderwidth="2")
    Frame55.configure(relief="flat")
    Frame55.configure(background="#ffffff")

    back_button = tkinter.Button(user_search_page, command=user_search_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Label1 = tkinter.Label(user_search_page)
    Label1.place(relx=0.36, rely=0.290, height=24, width=129)
    Label1.configure(background="#ffffff")
    Label1.configure(font=font9)
    Label1.configure(text='''Search :''')

    user_entry = tkinter.Entry(user_search_page)
    user_entry.place(relx=0.450, rely=0.290, height=24, relwidth=0.105)
    user_entry.configure(background="light gray")
    user_entry.configure(font=font9)
    user_entry.configure(justify='center')
    user_entry.configure(relief="flat")
    user_entry.configure(foreground="#ffffff")
    # user_entry.insert(0, 'user name')

    Label2 = tkinter.Label(user_search_page)
    Label2.place(relx=0.36, rely=0.250, height=24, width=380)
    Label2.configure(background="#ffffff")
    Label2.configure(font=font9)
    Label2.configure(text='''Search by (Location / Company / Language(en, per)) :''')

    search_entry = tkinter.Entry(user_search_page)
    search_entry.place(relx=0.60, rely=0.250, height=24, relwidth=0.105)
    search_entry.configure(background="light gray")
    search_entry.configure(font=font9)
    search_entry.configure(justify='center')
    search_entry.configure(relief="flat")
    search_entry.configure(foreground="#ffffff")
    # user_entry.insert(0, 'user name')

    search_speciality_button = tkinter.Button(user_search_page, command=lambda: search_profile_db(user_entry.get(), search_entry.get()))
    search_speciality_button.place(relx=0.37, rely=0.330, height=24, width=200)
    search_speciality_button.configure(activebackground="#dfe6e9")
    search_speciality_button.configure(background="#2d3436")
    search_speciality_button.configure(font=font9)
    search_speciality_button.configure(foreground="#ffffff")
    search_speciality_button.configure(relief="flat")
    search_speciality_button.configure(text='''Search''')

    return

def add_new_post_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global new_post_page
    new_post_page = tkinter.Tk()
    new_post_page.title('new Post')
    new_post_page.attributes('-fullscreen', True)
    new_post_page.configure(background="#2d3436")

    Frame30 = tkinter.Frame(new_post_page)
    Frame30.place(relx=0.325, rely=0.256, relheight=0.232, relwidth=0.357)
    Frame30.configure(borderwidth="2")
    Frame30.configure(relief="flat")
    Frame30.configure(background="#ffffff")

    back_button = tkinter.Button(new_post_page, command=new_post_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')


    Label30 = tkinter.Label(Frame30)
    Label30.place(relx=0.080, rely=0.430, height=24, relwidth=0.330)
    Label30.configure(background="white")
    Label30.configure(font=font9)
    Label30.configure(text='Enter Your Post Content :')

    media_entry = tkinter.Entry(Frame30)
    media_entry.place(relx=0.430, rely=0.430, height=24, relwidth=0.230)
    media_entry.configure(background="plum4")
    media_entry.configure(font=font9)
    media_entry.configure(relief="raised")
    media_entry.configure(justify="center")
    media_entry.configure(foreground="#ffffff")

    cursor.execute(f"select post_id from Posts1;")
    list_postid = (cursor.fetchall())
    new_postid = len(list_postid) + 1

    share_post_button = tkinter.Button(Frame30, command=lambda: post(media_entry.get(), new_postid))
    share_post_button.place(relx=0.710, rely=0.430, height=24, width=110)
    share_post_button.configure(activebackground="#dfe6e9")
    share_post_button.configure(background="#2d3436")
    share_post_button.configure(font=font9)
    share_post_button.configure(relief="flat")
    share_post_button.configure(foreground="orchid1")
    share_post_button.configure(text='''tab to share''')

    return

def check_cm_network():
    # Connections(connection_id int, email_me_to text, email_to_me text)
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    email_list3 = []
    cm_list = []
    cursor.execute(f"select * from Connections;")
    a = cursor.fetchall()

    for i in a:
        if i[2] == current_email:
            email_list3.append(i[1])

    cursor.execute(f"select * from Comments;")
    b = cursor.fetchall()

    for i in b:
        if i[3] in email_list3:
            cm_list.append(i[2])

    show_post_ui(cm_list)

    # connection.commit()
    # connection.close()

    return

def check_like_network():
    # Connections(connection_id int, email_me_to text, email_to_me text)
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    like_list = []
    email_list2=[]
    #LikePost(user_email,post_id ,like_id )
    cursor.execute(f"select * from Connections;")
    a = cursor.fetchall()
    for i in a:
        if i[2] == current_email:
            email_list2.append(i[1])

    cursor.execute(f"select * from LikePost;")
    b = cursor.fetchall()

    for i in b:
        if i[0] in email_list2:
            like_list.append(i[1])

    show_post_ui(like_list)

    # connection.commit()
    # connection.close()

    return

def check_post_network():
    # Connections(connection_id int, email_me_to text, email_to_me text)
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    email_list = []
    post_list = []
    # Posts1 (post_id, post_date, media , user_email)
    cursor.execute(f"select * from Connections;")
    a = cursor.fetchall()
    for i in a:
        if i[2] == current_email:
            email_list.append(i[1])

    cursor.execute(f"select * from Posts1;")
    b = cursor.fetchall()

    for i in b:
        if i[3] in email_list:
            post_list.append(i[0])

    show_post_ui(post_list)

    connection.commit()
    connection.close()

    return

def my_post_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    mypostid=[]
    cursor.execute(f"select post_id from Posts1 where user_email = '{current_email}';")
    mypost = cursor.fetchall()

    for i in range(len(mypost)):
        mypostid.append(mypost[i][0])

    show_post_ui(mypostid)
    connection.commit()
    return

def feed_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global feed_page

    feed_page = tkinter.Tk()
    feed_page.title('All Posts')
    feed_page.attributes('-fullscreen', True)
    feed_page.configure(background="#2d3436")

    Frame32 = tkinter.Frame(feed_page)
    Frame32.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.271)
    Frame32.configure(borderwidth="2")
    Frame32.configure(relief="flat")
    Frame32.configure(background="#ffffff")

    back_button = tkinter.Button(feed_page, command=feed_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    show_mypost_button = tkinter.Button(Frame32, command=my_post_ui)
    show_mypost_button.place(relx=0.071, rely=0.321, height=54, width=330)
    show_mypost_button.configure(activebackground="#dfe6e9")
    show_mypost_button.configure(background="#2d3436")
    show_mypost_button.configure(font=font9)
    show_mypost_button.configure(relief="flat")
    show_mypost_button.configure(foreground="white")
    show_mypost_button.configure(text='''My Posts''')

    add_new_button = tkinter.Button(Frame32, command=add_new_post_ui)
    add_new_button.place(relx=0.071, rely=0.151, height=54, width=330)
    add_new_button.configure(activebackground="#dfe6e9")
    add_new_button.configure(background="#2d3436")
    add_new_button.configure(font=font9)
    add_new_button.configure(relief="flat")
    add_new_button.configure(foreground="white")
    add_new_button.configure(text='''Add New Post''')

    show_network_post_button = tkinter.Button(Frame32, command=check_post_network)
    show_network_post_button.place(relx=0.071, rely=0.490, height=54, width=330)
    show_network_post_button.configure(activebackground="#dfe6e9")
    show_network_post_button.configure(background="#2d3436")
    show_network_post_button.configure(font=font9)
    show_network_post_button.configure(relief="flat")
    show_network_post_button.configure(foreground="white")
    show_network_post_button.configure(text='''Show your Network Posts''')

    show_network_like_button = tkinter.Button(Frame32, command=check_like_network)
    show_network_like_button.place(relx=0.071, rely=0.650, height=54, width=330)
    show_network_like_button.configure(activebackground="#dfe6e9")
    show_network_like_button.configure(background="#2d3436")
    show_network_like_button.configure(font=font9)
    show_network_like_button.configure(relief="flat")
    show_network_like_button.configure(foreground="white")
    show_network_like_button.configure(text='''Show posts that your network likes ''')

    show_network_cm_button = tkinter.Button(Frame32, command=check_cm_network)
    show_network_cm_button.place(relx=0.071, rely=0.820, height=54, width=330)
    show_network_cm_button.configure(activebackground="#dfe6e9")
    show_network_cm_button.configure(background="#2d3436")
    show_network_cm_button.configure(font=font9)
    show_network_cm_button.configure(relief="flat")
    show_network_cm_button.configure(foreground="white")
    show_network_cm_button.configure(text='''Show posts that your network comments''')


    return

def show_post_ui(input_list, index=0):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global posts_page

    posts_page = tkinter.Tk()
    posts_page.title('All Posts')
    posts_page.attributes('-fullscreen', True)
    posts_page.configure(background="#2d3436")

    Frame2 = tkinter.Frame(posts_page)
    Frame2.place(relx=0.325, rely=0.256, relheight=0.232, relwidth=0.357)
    Frame2.configure(borderwidth="2")
    Frame2.configure(relief="flat")
    Frame2.configure(background="#ffffff")

    back_button = tkinter.Button(posts_page, command=posts_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Frame1 = tkinter.Frame(posts_page)
    Frame1.place(relx=0.325, rely=0.556, relheight=0.232, relwidth=0.357)
    Frame1.configure(borderwidth="2")
    Frame1.configure(relief="flat")
    Frame1.configure(background="#ffffff")

    cursor.execute(
        f"""SELECT Posts1.post_id, media, Posts1.user_email, COUNT(Comments.comment_id), 0 FROM Posts1 INNER JOIN
         Comments ON Posts1.post_id=Comments.post_id GROUP BY Posts1.post_id;""")
    c = cursor.fetchall()

    cursor.execute(
        f"""SELECT Posts1.post_id, media, Posts1.user_email, 0, COUNT(like_id) FROM Posts1 INNER JOIN
                 LikePost ON Posts1.post_id=LikePost.post_id GROUP BY Posts1.post_id;""")
    res = cursor.fetchall()

    cursor.execute(
        f"""SELECT Posts1.post_id, media, Posts1.user_email, 0, 0 FROM Posts1 GROUP BY Posts1.post_id;""")
    res2 = cursor.fetchall()



    all_posts_and_cms_and_likes = []
    for post_comment in c:
        if post_comment[0] in input_list and post_comment[0] not in [x[0] for x in res]:
            all_posts_and_cms_and_likes.append(post_comment)
        else:
            for post_like in res:
                if post_comment[0] == post_like[0] and post_comment[0] in input_list:
                    all_posts_and_cms_and_likes.append(
                        (post_comment[0], post_comment[1], post_comment[2], post_comment[3] + post_like[3],
                         post_comment[4] + post_like[4]))

    for post_like in res:
        if post_like[0] in input_list and post_like[0] not in [x[0] for x in all_posts_and_cms_and_likes]:
            all_posts_and_cms_and_likes.append(post_like)

    list2 = []
    list3 = []
    for i in res2:
        if i[0] in input_list:
            list2.append(i)
    for j in all_posts_and_cms_and_likes:
        list3.append(j[0])
    if len(list2) != len(all_posts_and_cms_and_likes):
        for i in list2:
            if i[0] not in list3:
                all_posts_and_cms_and_likes.append(i)

    all_likes2 = []
    cursor.execute(
        f"SELECT post_id FROM LikePost where user_email = '{current_email}';")
    all_likes = cursor.fetchall()
    for i in all_likes:
        all_likes2.append(i[0])

    ids = []
    media = []
    user_email2 = []
    cms = []
    likes = []
    if index < len(all_posts_and_cms_and_likes):
        ids.append(all_posts_and_cms_and_likes[index][0])
        media.append(all_posts_and_cms_and_likes[index][1])
        user_email2.append(all_posts_and_cms_and_likes[index][2])
        cms.append(all_posts_and_cms_and_likes[index][3])
        likes.append(all_posts_and_cms_and_likes[index][4])

        Label20 = tkinter.Label(Frame1)
        Label20.place(relx=0.010, rely=0.100, height=24, relwidth=0.220)
        Label20.configure(background="white")
        Label20.configure(font=font9)
        Label20.configure(text='add comments')

        comment_entry = tkinter.Entry(Frame1)
        comment_entry.place(relx=0.010, rely=0.250, height=24, relwidth=0.230)
        comment_entry.configure(background="dark gray")
        comment_entry.configure(font=font9)
        comment_entry.configure(relief="raised")
        comment_entry.configure(justify="center")
        comment_entry.configure(foreground="#ffffff")


        cursor.execute(f"select comment_id from Comments where post_id = '{all_posts_and_cms_and_likes[index][0]}';")
        a =cursor.fetchall()
        a2 = len(a)+1

        comment_button = tkinter.Button(Frame1,
                                        command=lambda: comment(all_posts_and_cms_and_likes[index][0],a2,
                                                                comment_entry.get(), current_email))
        comment_button.place(relx=0.010, rely=0.460, height=24, width=110)
        comment_button.configure(activebackground="#dfe6e9")
        comment_button.configure(background="#2d3436")
        comment_button.configure(font=font9)
        comment_button.configure(relief="flat")
        comment_button.configure(foreground="white")
        comment_button.configure(text='''tab to share cm''')

        delete_post_button = tkinter.Button(Frame1,
                                            command=lambda: delete_post(current_email,
                                                                        all_posts_and_cms_and_likes[index][0]))
        delete_post_button.place(relx=0.350, rely=0.661, height=24, width=140)
        delete_post_button.configure(activebackground="#dfe6e9")
        delete_post_button.configure(background="#2d3436")
        delete_post_button.configure(font=font9)
        delete_post_button.configure(relief="flat")
        delete_post_button.configure(foreground="white")
        delete_post_button.configure(text='''tab to delete post''')

        Label21 = tkinter.Label(Frame1)
        Label21.place(relx=0.740, rely=0.100, height=24, relwidth=0.230)
        Label21.configure(background="white")
        Label21.configure(font=font9)
        Label21.configure(text='Share to')

        share_entry = tkinter.Entry(Frame1)
        share_entry.place(relx=0.750, rely=0.250, height=24, relwidth=0.230)
        share_entry.configure(background="dark gray")
        share_entry.configure(font=font9)
        share_entry.configure(relief="raised")
        share_entry.configure(justify="center")
        share_entry.configure(foreground="#ffffff")

        Label22 = tkinter.Label(Frame1)
        Label22.place(relx=0.750, rely=0.430, height=24, relwidth=0.230)
        Label22.configure(background="white")
        Label22.configure(font=font9)
        Label22.configure(text='choose direct')

        direct_entry = tkinter.Entry(Frame1)
        direct_entry.place(relx=0.750, rely=0.560, height=24, relwidth=0.230)
        direct_entry.configure(background="dark gray")
        direct_entry.configure(font=font9)
        direct_entry.configure(relief="raised")
        direct_entry.configure(justify="center")
        direct_entry.configure(foreground="#ffffff")

        share_button = tkinter.Button(Frame1, command=lambda: share_post(direct_entry.get(), share_entry.get(),
                                                                         all_posts_and_cms_and_likes[index][0]))
        share_button.place(relx=0.750, rely=0.740, height=24, width=110)
        share_button.configure(activebackground="#dfe6e9")
        share_button.configure(background="#2d3436")
        share_button.configure(font=font9)
        share_button.configure(relief="flat")
        share_button.configure(foreground="white")
        share_button.configure(text='''tab to share''')

        see_comments_button = tkinter.Button(Frame1, command=lambda: all_comment( all_posts_and_cms_and_likes[index][0]))
        see_comments_button.place(relx=0.020, rely=0.661, height=24, width=140)
        see_comments_button.configure(activebackground="#dfe6e9")
        see_comments_button.configure(background="Lavender")
        see_comments_button.configure(font=font9)
        see_comments_button.configure(relief="flat")
        see_comments_button.configure(foreground="Black")
        see_comments_button.configure(text='''Show All Comments''')

        Label20 = tkinter.Label(Frame1)
        Label20.place(relx=0.380, rely=0.090, height=24, relwidth=0.230)
        Label20.configure(background="white")
        Label20.configure(font=font9)
        Label20.configure(text='add like')
        ##############################################
        Label23 = tkinter.Label(Frame2)
        Label23.place(relx=0.200, rely=0.090, height=24, relwidth=0.230)
        Label23.configure(background="white")
        Label23.configure(font=font9)
        Label23.configure(text='user email : ')

        Label23a = tkinter.Label(Frame2)
        Label23a.place(relx=0.430, rely=0.090, height=24, relwidth=0.230)
        Label23a.configure(background="white")
        Label23a.configure(font=font9)
        Label23a.configure(text=user_email2)

        Label24 = tkinter.Label(Frame2)
        Label24.place(relx=0.200, rely=0.200, height=24, relwidth=0.230)
        Label24.configure(background="white")
        Label24.configure(font=font9)
        Label24.configure(text='media content : ')

        Label24a = tkinter.Label(Frame2)
        Label24a.place(relx=0.430, rely=0.200, height=24, relwidth=0.230)
        Label24a.configure(background="white")
        Label24a.configure(font=font9)
        Label24a.configure(text=media)

        Label25 = tkinter.Label(Frame2)
        Label25.place(relx=0.200, rely=0.400, height=24, relwidth=0.230)
        Label25.configure(background="white")
        Label25.configure(font=font9)
        Label25.configure(text='count like : ')

        Label25a = tkinter.Label(Frame2)
        Label25a.place(relx=0.430, rely=0.400, height=24, relwidth=0.230)
        Label25a.configure(background="white")
        Label25a.configure(font=font9)
        Label25a.configure(text=likes)

        Label26 = tkinter.Label(Frame2)
        Label26.place(relx=0.200, rely=0.300, height=24, relwidth=0.250)
        Label26.configure(background="white")
        Label26.configure(font=font9)
        Label26.configure(text='count comments : ')

        Label26a = tkinter.Label(Frame2)
        Label26a.place(relx=0.450, rely=0.300, height=24, relwidth=0.230)
        Label26a.configure(background="white")
        Label26a.configure(font=font9)
        Label26a.configure(text=cms)

        ##############################################
        if all_posts_and_cms_and_likes[index][0] in all_likes2:
            cursor.execute(
                f"SELECT like_id FROM LikePost where user_email = '{current_email}'and post_id = '{all_posts_and_cms_and_likes[index][0]}'")
            like_this_post = cursor.fetchone()
            like_button = tkinter.Button(Frame1,
                                         command=lambda: delete_like(current_email,
                                                                     all_posts_and_cms_and_likes[index][0],
                                                                     like_this_post))
            like_button.place(relx=0.380, rely=0.251, height=24, width=100)
            like_button.configure(activebackground="#dfe6e9")
            like_button.configure(background="#2d3436")
            like_button.configure(font=font9)
            like_button.configure(relief="flat")
            like_button.configure(foreground="red")
            like_button.configure(text='Dislike')
        elif all_posts_and_cms_and_likes[index][0] not in all_likes2:
            like_button = tkinter.Button(Frame1,
                                         command=lambda: like_post(current_email,
                                                                   all_posts_and_cms_and_likes[index][0]))
            like_button.place(relx=0.380, rely=0.251, height=24, width=100)
            like_button.configure(activebackground="#dfe6e9")
            like_button.configure(background="#2d3436")
            like_button.configure(font=font9)
            like_button.configure(relief="flat")
            like_button.configure(foreground="Red")
            like_button.configure(text='Like')

        if index == 0 and len(all_posts_and_cms_and_likes) != 0:
            next_button = tkinter.Button(posts_page,
                                         command=lambda: show_post_ui(input_list,
                                                                      index + 1))
            next_button.place(relx=0.70, rely=0.80, height=24, width=80)
            next_button.configure(activebackground="white")
            next_button.configure(background="#2d3436")
            next_button.configure(font=font9)
            next_button.configure(relief="flat")
            next_button.configure(text='''Next Post''')
            next_button.configure(foreground="#ffffff")

        elif index != 0 and index == len(all_posts_and_cms_and_likes) - 1:

            previous_button = tkinter.Button(posts_page,
                                             command=lambda: show_post_ui(input_list,
                                                                          index - 1))
            previous_button.place(relx=0.20, rely=0.80, height=24, width=120)
            previous_button.configure(activebackground="#dfe6e9")
            previous_button.configure(background="#2d3436")
            previous_button.configure(font=font9)
            previous_button.configure(relief="flat")
            previous_button.configure(text='''Previous Post''')
            previous_button.configure(foreground="#ffffff")

        elif index != 0 and index != len(all_posts_and_cms_and_likes) - 1:

            next_button = tkinter.Button(posts_page,
                                         command=lambda: show_post_ui(input_list,
                                                                      index + 1))
            next_button.place(relx=0.70, rely=0.80, height=24, width=80)
            next_button.configure(activebackground="#dfe6e9")
            next_button.configure(background="#2d3436")
            next_button.configure(font=font9)
            next_button.configure(relief="flat")
            next_button.configure(text='''Next Post''')
            next_button.configure(foreground="#ffffff")

            previous_button = tkinter.Button(posts_page,
                                             command=lambda: show_post_ui(input_list,
                                                                          index - 1))
            previous_button.place(relx=0.20, rely=0.80, height=24, width=120)
            previous_button.configure(activebackground="#dfe6e9")
            previous_button.configure(background="#2d3436")
            previous_button.configure(font=font9)
            previous_button.configure(relief="flat")
            previous_button.configure(text='''Previous Post''')
            previous_button.configure(foreground="#ffffff")

    connection.commit()
    connection.close()

    return

def show_chat_ui(dc_id):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global chat_page

    chat_page = tkinter.Tk()
    chat_page.title('show chat')
    chat_page.attributes('-fullscreen', True)
    chat_page.configure(background="#2d3436")

    Frame55 = tkinter.Frame(chat_page)
    Frame55.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.371)
    Frame55.configure(borderwidth="2")
    Frame55.configure(relief="flat")
    Frame55.configure(background="#ffffff")

    back_button = tkinter.Button(chat_page, command=chat_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    Label69 = tkinter.Label(Frame55)
    Label69.place(relx=0.045, rely=0.05, height=24, relwidth=0.490)
    Label69.configure(background="white")
    Label69.configure(font=font9)
    Label69.configure(text='Search :')

    search_entry = tkinter.Entry(Frame55)
    search_entry.place(relx=0.400, rely=0.05, height=24, relwidth=0.230)
    search_entry.configure(background="dark gray")
    search_entry.configure(font=font9)
    search_entry.configure(relief="raised")
    search_entry.configure(justify="center")
    search_entry.configure(foreground="#ffffff")

    send_pm_button = tkinter.Button(Frame55, command=lambda: search_in_direct_ui(dc_id, search_entry.get()))
    send_pm_button.place(relx=0.650, rely=0.05, height=24, width=60)
    send_pm_button.configure(activebackground="#dfe6e9")
    send_pm_button.configure(background="#2d3436")
    send_pm_button.configure(font=font9)
    send_pm_button.configure(relief="flat")
    send_pm_button.configure(foreground="white")
    send_pm_button.configure(text='''Search''')

    cursor.execute(
        f"select message_text from Messages where direct_id = '{dc_id}' and email_sender = '{current_email}'; ")
    list_message_me = cursor.fetchall()

    if list_message_me != [] and len(list_message_me) == 1:
        Label51 = tkinter.Label(Frame55)
        Label51.place(relx=0.645, rely=0.2, height=24, relwidth=0.290)
        Label51.configure(background="white")
        Label51.configure(font=font9)
        Label51.configure(text='you :')

        Label52 = tkinter.Label(Frame55)
        Label52.place(relx=0.645, rely=0.35, height=24, relwidth=0.290)
        Label52.configure(background="white")
        Label52.configure(font=font9)
        Label52.configure(foreground="magenta4")
        Label52.configure(text=list_message_me[0])

    if list_message_me != [] and len(list_message_me) == 2:
        Label51 = tkinter.Label(Frame55)
        Label51.place(relx=0.645, rely=0.2, height=24, relwidth=0.290)
        Label51.configure(background="white")
        Label51.configure(font=font9)
        Label51.configure(text='you :')

        Label52 = tkinter.Label(Frame55)
        Label52.place(relx=0.645, rely=0.35, height=24, relwidth=0.290)
        Label52.configure(background="white")
        Label52.configure(font=font9)
        Label52.configure(foreground="magenta4")
        Label52.configure(text=list_message_me[0])

        Label53 = tkinter.Label(Frame55)
        Label53.place(relx=0.645, rely=0.39, height=24, relwidth=0.290)
        Label53.configure(background="white")
        Label53.configure(font=font9)
        Label53.configure(foreground="magenta4")
        Label53.configure(text=list_message_me[1])


    if list_message_me != [] and len(list_message_me) > 3:
        Label51 = tkinter.Label(Frame55)
        Label51.place(relx=0.645, rely=0.2, height=24, relwidth=0.290)
        Label51.configure(background="white")
        Label51.configure(font=font9)
        Label51.configure(text='you :')

        Label52 = tkinter.Label(Frame55)
        Label52.place(relx=0.645, rely=0.35, height=24, relwidth=0.290)
        Label52.configure(background="white")
        Label52.configure(font=font9)
        Label52.configure(foreground="magenta4")
        Label52.configure(text=list_message_me[0])

        Label53 = tkinter.Label(Frame55)
        Label53.place(relx=0.645, rely=0.39, height=24, relwidth=0.290)
        Label53.configure(background="white")
        Label53.configure(font=font9)
        Label53.configure(foreground="magenta4")
        Label53.configure(text=list_message_me[1])

        Label54 = tkinter.Label(Frame55)
        Label54.place(relx=0.645, rely=0.53, height=24, relwidth=0.290)
        Label54.configure(background="white")
        Label54.configure(font=font9)
        Label54.configure(foreground="magenta4")
        Label54.configure(text=list_message_me[2])

    cursor.execute(
        f"select email_receiver from Directs where direct_id = '{dc_id}' and email_sender = '{current_email}' ")
    other = cursor.fetchone()

    if other is None:
        cursor.execute(
            f"select email_sender from Directs where direct_id = '{dc_id}' and email_receiver = '{current_email}'")
        other = cursor.fetchone()
        other = other[0]
    else:
        other = other[0]
    cursor.execute(
        f"select message_text from Messages where direct_id = '{dc_id}' and email_sender = '{other}' ")
    list_message_to_me = cursor.fetchall()
    if list_message_to_me == [] or list_message_to_me is None:
        cursor.execute(
            f"select message_text from Messages where direct_id = '{dc_id}' and email_receiver = '{other}' ")
    cursor.execute(
        f"select message_id from Messages where direct_id = '{dc_id}' ")
    other2 = cursor.fetchall()
    other3 = len(other2)

    if list_message_to_me != [] and len(list_message_to_me) == 1:
        Label55 = tkinter.Label(Frame55)
        Label55.place(relx=0.045, rely=0.20, height=24, relwidth=0.290)
        Label55.configure(background="white")
        Label55.configure(font=font9)
        Label55.configure(text='other :')

        Label56 = tkinter.Label(Frame55)
        Label56.place(relx=0.045, rely=0.3, height=24, relwidth=0.290)
        Label56.configure(background="white")
        Label56.configure(font=font9)
        Label56.configure(foreground="tan4")
        Label56.configure(text=list_message_to_me[0])

    if list_message_to_me != [] and len(list_message_to_me) == 2:
        Label55 = tkinter.Label(Frame55)
        Label55.place(relx=0.045, rely=0.20, height=24, relwidth=0.290)
        Label55.configure(background="white")
        Label55.configure(font=font9)
        Label55.configure(text='other :')

        Label56 = tkinter.Label(Frame55)
        Label56.place(relx=0.045, rely=0.3, height=24, relwidth=0.290)
        Label56.configure(background="white")
        Label56.configure(font=font9)
        Label56.configure(foreground="tan4")
        Label56.configure(text=list_message_to_me[0])

        Label57 = tkinter.Label(Frame55)
        Label57.place(relx=0.045, rely=0.45, height=24, relwidth=0.290)
        Label57.configure(background="white")
        Label57.configure(font=font9)
        Label57.configure(foreground="tan4")
        Label57.configure(text=list_message_to_me[1])


    if list_message_to_me != [] and len(list_message_to_me) > 3:
        Label55 = tkinter.Label(Frame55)
        Label55.place(relx=0.045, rely=0.20, height=24, relwidth=0.290)
        Label55.configure(background="white")
        Label55.configure(font=font9)
        Label55.configure(text='other :')

        Label56 = tkinter.Label(Frame55)
        Label56.place(relx=0.045, rely=0.3, height=24, relwidth=0.290)
        Label56.configure(background="white")
        Label56.configure(font=font9)
        Label56.configure(foreground="tan4")
        Label56.configure(text=list_message_to_me[0])

        Label57 = tkinter.Label(Frame55)
        Label57.place(relx=0.045, rely=0.45, height=24, relwidth=0.290)
        Label57.configure(background="white")
        Label57.configure(font=font9)
        Label57.configure(foreground="tan4")
        Label57.configure(text=list_message_to_me[1])

        Label58 = tkinter.Label(Frame55)
        Label58.place(relx=0.045, rely=0.6, height=24, relwidth=0.290)
        Label58.configure(background="white")
        Label58.configure(font=font9)
        Label58.configure(foreground="tan4")
        Label58.configure(text=list_message_to_me[2])

    Label49 = tkinter.Label(Frame55)
    Label49.place(relx=0.045, rely=0.89, height=24, relwidth=0.490)
    Label49.configure(background="white")
    Label49.configure(font=font9)
    Label49.configure(text='enter message to send :')

    send_pm_entry = tkinter.Entry(Frame55)
    send_pm_entry.place(relx=0.500, rely=0.89, height=24, relwidth=0.230)
    send_pm_entry.configure(background="dark gray")
    send_pm_entry.configure(font=font9)
    send_pm_entry.configure(relief="raised")
    send_pm_entry.configure(justify="center")
    send_pm_entry.configure(foreground="#ffffff")

    send_pm_button = tkinter.Button(Frame55, command=lambda: send_message_db(other3, dc_id, current_email, other, send_pm_entry.get()))
    send_pm_button.place(relx=0.750, rely=0.89, height=24, width=60)
    send_pm_button.configure(activebackground="#dfe6e9")
    send_pm_button.configure(background="#2d3436")
    send_pm_button.configure(font=font9)
    send_pm_button.configure(relief="flat")
    send_pm_button.configure(foreground="white")
    send_pm_button.configure(text='''Send''')

    cursor.execute(
        f"select message_text from Messages where direct_id = '{dc_id}' and email_sender = '{current_email}' ")
    list_message_me_new = cursor.fetchall()

    if list_message_me_new != []:
        Label54 = tkinter.Label(Frame55)
        Label54.place(relx=0.645, rely=0.67, height=24, relwidth=0.290)
        Label54.configure(background="white")
        Label54.configure(font=font9)
        Label54.configure(foreground="magenta4")
        Label54.configure(text=list_message_me_new[-1])
    # else:
    #     if list_message_me_new != []:
    #         Label54 = tkinter.Label(Frame55)
    #         Label54.place(relx=0.645, rely=0.67, height=24, relwidth=0.290)
    #         Label54.configure(background="white")
    #         Label54.configure(font=font9)
    #         Label54.configure(foreground="magenta4")
    #         Label54.configure(text=list_message_me_new[-1])

    return

def search_in_direct_ui(direct_id, search):
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    cursor.execute(
        f"select message_text from Messages where direct_id = '{direct_id}' and email_sender = '{current_email}' and message_text LIKE '%{search}%'; ")
    list_message_me = cursor.fetchall()

    cursor.execute(
        f"select message_text from Messages where direct_id = '{direct_id}' and email_receiver = '{current_email}' and message_text LIKE '%{search}%'")
    list_message_to_me = cursor.fetchall()

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global direct_search_page

    direct_search_page = tkinter.Tk()
    direct_search_page.title('show chat')
    direct_search_page.attributes('-fullscreen', True)
    direct_search_page.configure(background="#2d3436")

    Frame55 = tkinter.Frame(direct_search_page)
    Frame55.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.371)
    Frame55.configure(borderwidth="2")
    Frame55.configure(relief="flat")
    Frame55.configure(background="#ffffff")

    back_button = tkinter.Button(direct_search_page, command=direct_search_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    if list_message_me == [] and list_message_to_me == []:
        Label56 = tkinter.Label(Frame55)
        Label56.place(relx=0.35, rely=0.02, height=24, relwidth=0.290)
        Label56.configure(background="light coral")
        Label56.configure(font=font9)
        Label56.configure(foreground="black")
        Label56.configure(text="Couldn't find anything")
        Label56.after(2000, Label56.destroy)

    else:
        rely1 = 0.05
        for me in list_message_me:
            Label56 = tkinter.Label(Frame55)
            Label56.place(relx=0.65, rely=rely1, height=24, relwidth=0.290)
            Label56.configure(background="white")
            Label56.configure(font=font9)
            Label56.configure(foreground="magenta4")
            Label56.configure(text=me)
            rely1 += 0.05

        rely2 = 0.08
        for other in list_message_to_me:
            Label56 = tkinter.Label(Frame55)
            Label56.place(relx=0.045, rely=rely2, height=24, relwidth=0.290)
            Label56.configure(background="white")
            Label56.configure(font=font9)
            Label56.configure(foreground="tan4")
            Label56.configure(text=other)
            rely2 += 0.05


    return

def home_page_ui():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()
    global home_page

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'

    font10 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    home_page = tkinter.Tk()
    home_page.configure(background="#2d3436")
    home_page.configure(cursor="arrow")
    home_page.title('Home Page')
    home_page.attributes('-fullscreen', True)

    back_button = tkinter.Button(home_page, command=home_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="#2d3436")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')

    menu_frame = tkinter.Frame(home_page)
    menu_frame.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.271)
    menu_frame.configure(relief='flat')
    menu_frame.configure(borderwidth="2")
    menu_frame.configure(background="#d9d9d9")
    menu_frame.configure(cursor="tcross")

    profile_button = tkinter.Button(menu_frame, command=profilePage_ui)
    profile_button.place(relx=0.071, rely=0.321, height=54, width=330)
    profile_button.configure(activebackground="#f9f9f9")
    profile_button.configure(background="#ffffff")
    profile_button.configure(borderwidth="5")
    profile_button.configure(cursor="mouse")
    profile_button.configure(font=font9)
    profile_button.configure(text='''View Profile''')

    direct_button = tkinter.Button(menu_frame, command=show_directs_ui)
    direct_button.place(relx=0.071, rely=0.666, height=54, width=330)
    direct_button.configure(activebackground="#f9f9f9")
    direct_button.configure(background="#ffffff")
    direct_button.configure(borderwidth="5")
    direct_button.configure(font=font9)
    direct_button.configure(text='''Messaging''')

    direct_button = tkinter.Button(menu_frame, command=notification)
    direct_button.place(relx=0.071, rely=0.776, height=54, width=330)
    direct_button.configure(activebackground="#f9f9f9")
    direct_button.configure(background="#ffffff")
    direct_button.configure(borderwidth="5")
    direct_button.configure(font=font9)
    direct_button.configure(text='''Notification''')

    post_button = tkinter.Button(menu_frame, command=feed_ui)
    post_button.place(relx=0.071, rely=0.556, height=54, width=330)
    post_button.configure(activebackground="#f9f9f9")
    post_button.configure(background="#ffffff")
    post_button.configure(borderwidth="5")
    post_button.configure(font=font9)
    post_button.configure(text='''Feed Page''')

    search_button = tkinter.Button(menu_frame, command=user_search_ui)
    search_button.place(relx=0.071, rely=0.446, height=54, width=330)
    search_button.configure(activebackground="#f9f9f9")
    search_button.configure(background="#ffffff")
    search_button.configure(borderwidth="5")
    search_button.configure(font=font9)
    search_button.configure(text='''Search''')

    return

def exit_ui():
    root.destroy()

def notification():
    connection = sqlite3.connect('Linkedin.db')
    cursor = connection.cursor()

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family {DejaVu Sans Mono} -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global notif_page

    notif_page = tkinter.Tk()
    notif_page.title('notification')
    notif_page.attributes('-fullscreen', True)
    notif_page.configure(background="#2d3436")

    Frame55 = tkinter.Frame(notif_page)
    Frame55.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.271)
    Frame55.configure(borderwidth="2")
    Frame55.configure(relief="flat")
    Frame55.configure(background="#ffffff")

    back_button = tkinter.Button(notif_page, command=notif_page.destroy)
    back_button.place(relx=0.016, rely=0.02, height=54, width=71)
    back_button.configure(activeforeground="#2d3436")
    back_button.configure(background="Black")
    back_button.configure(font=font9)
    back_button.configure(foreground="#ffffff")
    back_button.configure(relief="flat")
    back_button.configure(text='''Back''')


    global notif_list
    notif_list = []
    rely2 = 0.290
    if notif_list != []:
        for i in notif_list:
            if i[0] == 'like':
                T = notif_list[3] + 'liked your post'
            elif i[0] == 'visit':
                T = notif_list[3] + 'visited your profile'
            elif i[0] == 'comment':
                T = notif_list[3] + 'commented on your post'
            elif i[0] == 'endorse':
                T = notif_list[3] + 'endorsed your skill'

            Label1 = tkinter.Label(notif_page)
            Label1.place(relx=0.360, rely=rely2, height=24, width=329)
            Label1.configure(background="#ffffff")
            Label1.configure(font=font9)
            Label1.configure(text=T)
            rely2 += 0.55
    else:
        Label1 = tkinter.Label(notif_page)
        Label1.place(relx=0.360, rely=0.290, height=24, width=329)
        Label1.configure(background="#ffffff")
        Label1.configure(font=font9)
        Label1.configure(foreground="Red")
        Label1.configure(text='your notification is empty.')


    return

def start():

    _bgcolor = '#d9d9d9'
    _fgcolor = '#000000'
    _compcolor = '#d9d9d9'
    _ana1color = '#d9d9d9'
    _ana2color = '#ececec'
    font9 = "-family ubvazir -size 10 -weight bold -slant roman -underline 0 -overstrike 0"

    global root

    root = tkinter.Tk()
    root.title('TabibYab')
    root.attributes('-fullscreen', True)
    root.configure(background="#2d3436")

    start_frame = tkinter.Frame(root)
    start_frame.place(relx=0.351, rely=0.202, relheight=0.537, relwidth=0.271)
    start_frame.configure(relief='flat')
    start_frame.configure(borderwidth="2")
    start_frame.configure(background="#ffffff")

    login_button = tkinter.Button(start_frame, command=login_ui)
    login_button.place(relx=0.074, rely=0.221, height=54, width=351)
    login_button.configure(activebackground="#dfe6e9")
    login_button.configure(background="#2d3436")
    login_button.configure(font=font9)
    login_button.configure(relief="flat")
    login_button.configure(foreground="#ffffff")
    login_button.configure(text='''Login''')

    signup_button = tkinter.Button(start_frame, command=signup_ui)
    signup_button.place(relx=0.074, rely=0.526, height=54, width=351)
    signup_button.configure(activebackground="#dfe6e9")
    signup_button.configure(background="#2d3436")
    signup_button.configure(font=font9)
    signup_button.configure(relief="flat")
    signup_button.configure(text='''Sign Up''')
    signup_button.configure(foreground="#ffffff")

    exit_button = tkinter.Button(start_frame, command=root.destroy)
    exit_button.place(relx=0.074, rely=0.846, height=54, width=351)
    exit_button.configure(activebackground="#dfe6e9")
    exit_button.configure(background="#2d3436")
    exit_button.configure(font=font9)
    exit_button.configure(relief="flat")
    exit_button.configure(text='''Exit''')
    exit_button.configure(foreground="#ffffff")

    Label1 = tkinter.Label(start_frame)
    Label1.place(relx=0.099, rely=0.145, height=24, width=329)
    Label1.configure(background="#ffffff")
    Label1.configure(font=font9)
    Label1.configure(text='''Already Have An Account?''')

    Label1_3 = tkinter.Label(start_frame)
    Label1_3.place(relx=0.074, rely=0.45, height=24, width=349)
    Label1_3.configure(activebackground="#f9f9f9")
    Label1_3.configure(background="#ffffff")
    Label1_3.configure(font="-family {ubvazir} -size 10 -weight bold")
    Label1_3.configure(text='''Still Does Not Have An Account?''')

    root.mainloop()

    return



start()
